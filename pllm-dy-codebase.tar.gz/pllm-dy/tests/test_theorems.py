"""
PLLM-DY Theorem and Property Verification Tests
=================================================
Automated tests verifying the paper's theorems and core properties.
Run with: pytest tests/ -v
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
import numpy as np

from src.term_algebra import *
from src.derivation_rules import *
from src.epsilon_feasibility import *
from src.attack_graph import AttackGraph, AgentNode, CommunicationChannel


# ============================================================================
# Term Algebra Tests (Definition 1)
# ============================================================================

class TestTermAlgebra:
    """Tests for Definition 1: PLLM-DY Term Algebra."""

    def test_atomic_terms(self):
        n = Name("Alice")
        assert n.is_atomic
        assert n.depth == 0

    def test_pair_projection(self):
        a = Name("A")
        b = Nonce("n1")
        p = Pair(a, b)
        assert Fst(p) == a
        assert Snd(p) == b

    def test_encryption_decryption(self):
        """DY property: dec(enc(m, k), k) = m"""
        m = Name("secret")
        k = SecretKey("Bob")
        c = Enc(m, k)
        assert Dec(c, k) == m

    def test_encryption_wrong_key(self):
        """DY property: cannot decrypt without correct key."""
        m = Name("secret")
        k1 = SecretKey("Bob")
        k2 = SecretKey("Eve")
        c = Enc(m, k1)
        result = Dec(c, k2)
        assert result != m

    def test_sign_verify(self):
        """DY property: verify(sign(m, sk), pk(sk)) = m"""
        m = Name("message")
        sk = SecretKey("Alice")
        pk = PublicKey("Alice")
        sig = Sign(m, sk)
        assert Verify(sig, pk) == m

    def test_sign_wrong_key(self):
        """Cannot verify signature with wrong public key."""
        m = Name("message")
        sk = SecretKey("Alice")
        pk_wrong = PublicKey("Bob")
        sig = Sign(m, sk)
        assert Verify(sig, pk_wrong) is None

    def test_llm_agent_term(self):
        """T_P extension: LLM agent terms."""
        agent = LLMAgent("A1", 0.7, 128000, 0.7)
        assert agent.term_type == TermType.LLM_AGENT

    def test_tool_invocation_term(self):
        """T_P extension: Tool terms."""
        tool = ToolInvocation("search", Name("query"), ToolOutput("search", "result"))
        assert tool.term_type == TermType.TOOL

    def test_probabilistic_term(self):
        """T_P extension: Probabilistic terms."""
        pt = ProbabilisticTerm(Action("A1", "send"), "bernoulli")
        assert pt.term_type == TermType.PROBABILISTIC

    def test_knowledge_set_closure(self):
        """Classical DY closure adds derivable terms."""
        m = Name("secret")
        k = SecretKey("Bob")
        c = Enc(m, k)
        S = KnowledgeSet({c, k})
        S_closed = S.classical_closure()
        assert S_closed.contains(m)  # Should derive m from enc(m,k) and k


# ============================================================================
# Derivation Rule Tests (Definitions 2-3)
# ============================================================================

class TestDerivationRules:
    """Tests for Definitions 2-3: Probabilistic derivation rules."""

    def setup_method(self):
        self.engine = DerivationEngine()
        self.theta_robust = LLMParameters("robust", temperature=0.3,
                                          alignment_robustness=0.9)
        self.theta_weak = LLMParameters("weak", temperature=1.5,
                                        alignment_robustness=0.2)

    def test_r1_probability_range(self):
        """R1 probability must be in [0, 1]."""
        prompt = Prompt("test", is_adversarial=True)
        for tau in np.linspace(0, 2, 20):
            for phi in np.linspace(0.1, 0.95, 20):
                theta = LLMParameters("t", temperature=tau,
                                     alignment_robustness=phi)
                step = self.engine.apply_r1(KnowledgeSet(), theta, prompt)
                assert 0 <= step.probability <= 1

    def test_r1_temperature_monotonicity(self):
        """Higher temperature -> higher attack success (R1)."""
        prompt = Prompt("test", is_adversarial=True)
        probs = []
        for tau in [0.1, 0.5, 1.0, 1.5, 2.0]:
            theta = LLMParameters("t", temperature=tau,
                                 alignment_robustness=0.5)
            step = self.engine.apply_r1(KnowledgeSet(), theta, prompt)
            probs.append(step.probability)
        # Should be non-decreasing
        for i in range(len(probs) - 1):
            assert probs[i] <= probs[i + 1] + 1e-10

    def test_r1_alignment_monotonicity(self):
        """Higher alignment -> lower attack success (R1)."""
        prompt = Prompt("test", is_adversarial=True)
        probs = []
        for phi in [0.1, 0.3, 0.5, 0.7, 0.9]:
            theta = LLMParameters("t", temperature=0.7,
                                 alignment_robustness=phi)
            step = self.engine.apply_r1(KnowledgeSet(), theta, prompt)
            probs.append(step.probability)
        # Should be non-increasing
        for i in range(len(probs) - 1):
            assert probs[i] >= probs[i + 1] - 1e-10

    def test_r2_two_stage(self):
        """R2 has deterministic Stage 1 and probabilistic Stage 2."""
        corrupted = ToolOutput("search", "malicious")
        attack = AttackParameters(adversarial_content_ratio=0.1)
        s1, s2 = self.engine.apply_r2(
            KnowledgeSet(), self.theta_robust, "search", corrupted, attack
        )
        assert s1.probability == 1.0  # Stage 1 deterministic
        assert 0 < s2.probability < 1  # Stage 2 probabilistic

    def test_r4_trust_effect(self):
        """Higher trust -> higher cascade probability (R4)."""
        probs = []
        for trust in [0.1, 0.3, 0.5, 0.7, 0.9]:
            attack = AttackParameters(trust_level=trust)
            step = self.engine.apply_r4(
                KnowledgeSet(), self.theta_robust, self.theta_weak, attack
            )
            probs.append(step.probability)
        for i in range(len(probs) - 1):
            assert probs[i] <= probs[i + 1] + 1e-10

    def test_r5_below_threshold(self):
        """R5 returns 0 when similarity < threshold."""
        p1 = Prompt("original")
        p2 = Prompt("different")
        attack = AttackParameters(semantic_similarity=0.5)  # Below 0.85
        step = self.engine.apply_r5(KnowledgeSet(), p1, p2, attack)
        assert step.probability == 0.0

    def test_chain_probability(self):
        """Chain probability is product of individual steps."""
        steps = [
            DerivationStep(RuleType.R1_DPI, (), Action("A", "x"), 0.5),
            DerivationStep(RuleType.R4_AC, (), Action("B", "y"), 0.8),
        ]
        assert abs(self.engine.compute_chain_probability(steps) - 0.4) < 1e-10


# ============================================================================
# Theorem Tests
# ============================================================================

class TestTheorems:
    """Automated verification of paper theorems."""

    def test_theorem_1_subsumption(self):
        """
        Theorem 1: R2 subsumes R1 when prompt channel = tool.
        The key structural property: both rules can express
        the same adversarial capability.
        """
        engine = DerivationEngine()
        theta = LLMParameters("A1", temperature=0.7, alignment_robustness=0.7)

        # R1 can achieve hijacking
        prompt = Prompt("payload", is_adversarial=True)
        r1 = engine.apply_r1(KnowledgeSet(), theta, prompt)
        assert r1.probability > 0

        # R2 with prompt-as-tool can also achieve hijacking
        corrupted = ToolOutput("prompt_channel", "payload")
        attack = AttackParameters(adversarial_content_ratio=1.0)
        _, r2_s2 = engine.apply_r2(
            KnowledgeSet(), theta, "prompt_channel", corrupted, attack
        )
        assert r2_s2.probability > 0  # R2 can also derive the action

    def test_theorem_2_monotonicity(self):
        """
        Theorem 2(i): For ε_1 <= ε_2, Cap_ε2 ⊆ Cap_ε1.
        """
        cap = ProbabilisticCapabilitySet()

        # Build simple graph
        engine = DerivationEngine()
        theta = LLMParameters("A", temperature=0.7, alignment_robustness=0.7)
        prompt = Prompt("test", is_adversarial=True)

        steps = []
        for phi in [0.3, 0.5, 0.7, 0.9]:
            t = LLMParameters("A", temperature=0.7, alignment_robustness=phi)
            s = engine.apply_r1(KnowledgeSet(), t, prompt)
            steps.append(s)

        graph = {prompt: steps}
        sources = {prompt}
        targets = {s.conclusion for s in steps}
        cap.compute(graph, sources, targets)

        epsilons = [0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.8]
        result = verify_theorem_2(cap, epsilons)
        assert result["monotonicity"], "Theorem 2(i) monotonicity failed"

    def test_theorem_2_classical_consistency(self):
        """
        Theorem 2(iii): When all probabilities are 0 or 1,
        ε-feasible derivability = classical DY derivability.
        """
        cap = ProbabilisticCapabilitySet()

        # Only deterministic steps (p=1)
        step = DerivationStep(RuleType.CLASSICAL_DY, (), Name("derived"), 1.0)
        graph = {Name("source"): [step]}
        sources = {Name("source")}
        targets = {step.conclusion}
        cap.compute(graph, sources, targets)

        result = verify_theorem_2(cap, [0.01, 0.1, 0.5, 0.99])
        assert result["classical_consistency"], "Theorem 2(iii) failed"

    def test_theorem_3_completeness(self):
        """
        Theorem 3: Every OWASP attack class maps to PLLM-DY rules.
        """
        from experiments.taxonomy_mapping import verify_theorem_3
        result = verify_theorem_3()
        assert result["theorem_3_verified"], \
            f"Theorem 3 failed: {result}"

    def test_theorem_7_security_equivalence(self):
        """
        Theorem 7: ε_1(S) = ε_2(S) for both protocols.
        The LLM attack surface is identical regardless of
        the authentication infrastructure (centralized vs DID).
        """
        models = {
            "gpt4": (0.7, 0.70),
            "gpt35": (0.7, 0.45),
            "llama2": (0.6, 0.55),
        }

        for name, (tau, phi) in models.items():
            theta = LLMParameters(name, temperature=tau,
                                 alignment_robustness=phi)
            alpha_llm = max(
                f_dpi(theta),
                max(f_ipi(theta, AttackParameters(adversarial_content_ratio=r))
                    for r in [0.05, 0.1, 0.5, 1.0])
            )
            # Both protocols have the same ε bound (α_LLM)
            eps_p1 = alpha_llm
            eps_p2 = alpha_llm
            assert abs(eps_p1 - eps_p2) < 1e-15, \
                f"Theorem 7 failed for {name}: {eps_p1} != {eps_p2}"


# ============================================================================
# Integration Tests
# ============================================================================

class TestIntegration:
    """End-to-end integration tests."""

    def test_full_attack_graph(self):
        """Build and query a complete attack graph."""
        from src.agent_system import MultiAgentSystem
        mas = MultiAgentSystem()
        mas.create_default_system(5)
        mas.build_attack_graph()

        stats = mas.attack_graph.get_statistics()
        assert stats["num_agents"] == 5
        assert stats["num_edges"] > 0

    def test_cascade_simulation(self):
        """Monte Carlo cascade simulation produces valid probabilities."""
        from src.agent_system import MultiAgentSystem
        mas = MultiAgentSystem()
        mas.create_default_system(3)
        mas.build_attack_graph()

        result = mas.simulate_cascade("A1", ["A1", "A2", "A3"],
                                      initial_prob=0.3, num_trials=1000)
        assert 0 <= result["empirical_probability"] <= 1
        assert 0 <= result["theoretical_probability"] <= 1

    def test_protocol_execution(self):
        """Both protocols complete sessions successfully."""
        from models.protocol import CentralizedProtocol, DecentralizedDIDProtocol

        p1 = CentralizedProtocol()
        p1.register_agent("A")
        p1.register_agent("B")
        sess1 = p1.run_session("A", "B", Name("hello"))
        assert sess1.authenticated

        p2 = DecentralizedDIDProtocol()
        p2.register_did("A")
        p2.register_did("B")
        sess2 = p2.run_session("A", "B", Name("hello"))
        assert sess2.authenticated


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
