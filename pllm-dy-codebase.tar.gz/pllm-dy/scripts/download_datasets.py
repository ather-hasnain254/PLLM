#!/usr/bin/env python3
"""
PLLM-DY: Dataset Downloader
==============================
Downloads all 4 datasets used for empirical calibration of
PLLM-DY derivation success functions.

Datasets:
  1. JailbreakBench  -> Calibrates f_DPI (R1) and f_SE (R5)
  2. InjecAgent      -> Calibrates f_IPI (R2)
  3. AgentDojo       -> Validates epsilon-bounds on tool-use attacks
  4. DAN Jailbreaks  -> Calibrates R5 semantic equivalence

Usage:
    python scripts/download_datasets.py --all
    python scripts/download_datasets.py --dataset jailbreakbench
    python scripts/download_datasets.py --list
    python scripts/download_datasets.py --status
"""

import argparse
import json
import os
import subprocess
import sys
import shutil
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"

# ============================================================================
# Dataset Registry
# ============================================================================

DATASETS = {
    "jailbreakbench": {
        "description": "JailbreakBench: Standardized jailbreak attack benchmark",
        "paper_ref": "Chao et al., 2024; used in Zou et al. [33], Shen et al. [35]",
        "calibrates": "f_DPI (R1: Direct Prompt Injection), f_SE (R5: Semantic Equivalence)",
        "url": "https://github.com/JailbreakBench/jailbreakbench.git",
        "branch": "main",
        "target_dir": "jailbreakbench",
        "fallback_urls": [
            ("https://raw.githubusercontent.com/JailbreakBench/jailbreakbench/main/src/jailbreakbench/data/behaviors.csv",
             "jailbreakbench/behaviors.csv"),
            ("https://raw.githubusercontent.com/JailbreakBench/jailbreakbench/main/src/jailbreakbench/data/judge_prompts.csv",
             "jailbreakbench/judge_prompts.csv"),
        ],
    },
    "injecagent": {
        "description": "InjecAgent: Indirect prompt injection benchmark for tool-integrated LLM agents",
        "paper_ref": "Zhan et al. [38], arXiv:2403.02691",
        "calibrates": "f_IPI (R2: Indirect Prompt Injection via Tool-Output Corruption)",
        "url": "https://github.com/uiuc-kang-lab/InjecAgent.git",
        "branch": "main",
        "target_dir": "injecagent",
        "fallback_urls": [
            ("https://raw.githubusercontent.com/uiuc-kang-lab/InjecAgent/main/data/direct_tool_call_test_cases.json",
             "injecagent/direct_tool_call_test_cases.json"),
            ("https://raw.githubusercontent.com/uiuc-kang-lab/InjecAgent/main/data/indirect_tool_call_test_cases.json",
             "injecagent/indirect_tool_call_test_cases.json"),
        ],
    },
    "agentdojo": {
        "description": "AgentDojo: Dynamic environment for evaluating prompt injection on LLM agents",
        "paper_ref": "Debenedetti et al. [39], NeurIPS 2024",
        "calibrates": "epsilon-bounds validation on tool-use attacks (R2), agent robustness benchmarks",
        "url": "https://github.com/ethz-spylab/agentdojo.git",
        "branch": "main",
        "target_dir": "agentdojo",
        "fallback_urls": [
            ("https://raw.githubusercontent.com/ethz-spylab/agentdojo/main/pyproject.toml",
             "agentdojo/pyproject.toml"),
            ("https://raw.githubusercontent.com/ethz-spylab/agentdojo/main/README.md",
             "agentdojo/README.md"),
        ],
    },
    "dan_jailbreaks": {
        "description": "DAN Jailbreak Dataset: 1,405 in-the-wild jailbreak prompts (Shen et al., CCS 2024)",
        "paper_ref": "Shen et al. [35], ACM CCS 2024",
        "calibrates": "R5 semantic equivalence, R1 jailbreak success rate statistics",
        "url": "https://github.com/verazuo/jailbreak_llms.git",
        "branch": "main",
        "target_dir": "dan_jailbreaks",
        "fallback_urls": [
            ("https://raw.githubusercontent.com/verazuo/jailbreak_llms/main/data/prompts_example.csv",
             "dan_jailbreaks/prompts_example.csv"),
            ("https://raw.githubusercontent.com/verazuo/jailbreak_llms/main/data/jailbreak_prompts.csv",
             "dan_jailbreaks/jailbreak_prompts.csv"),
        ],
    },
}


def check_git():
    return shutil.which("git") is not None


def git_clone(url, target, branch="main"):
    if target.exists():
        print(f"    Already exists: {target}")
        try:
            subprocess.run(["git", "-C", str(target), "pull", "--ff-only"],
                           check=True, capture_output=True, timeout=120)
            print(f"    Pulled latest.")
            return True
        except Exception:
            print(f"    Pull failed, using existing data.")
            return True

    print(f"    git clone --depth 1 --branch {branch} {url}")
    try:
        subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", branch, url, str(target)],
            check=True, capture_output=True, timeout=300
        )
        return True
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode()[:200] if e.stderr else str(e)
        print(f"    Clone failed: {stderr}")
        return False
    except subprocess.TimeoutExpired:
        print(f"    Clone timed out after 300s.")
        return False


def download_file(url, dest):
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        print(f"    Exists: {dest}")
        return True
    print(f"    GET {url}")
    try:
        urllib.request.urlretrieve(url, str(dest))
        size = dest.stat().st_size
        print(f"    Saved: {dest} ({size:,} bytes)")
        return True
    except Exception as e:
        print(f"    FAILED: {e}")
        return False


def count_data_files(directory):
    """Count .csv/.json/.jsonl files recursively."""
    d = Path(directory)
    if not d.exists():
        return 0
    count = 0
    for ext in ["*.csv", "*.json", "*.jsonl", "*.py"]:
        count += len(list(d.rglob(ext)))
    return count


def download_one(name):
    if name not in DATASETS:
        print(f"  ERROR: Unknown dataset '{name}'")
        print(f"  Available: {', '.join(DATASETS.keys())}")
        return False

    ds = DATASETS[name]
    target = DATA_DIR / ds["target_dir"]
    print(f"\n  [{name}]")
    print(f"    {ds['description']}")
    print(f"    Calibrates: {ds['calibrates']}")

    ok = False

    # Strategy 1: git clone
    if check_git():
        ok = git_clone(ds["url"], target, ds.get("branch", "main"))
    else:
        print(f"    git not found, skipping clone.")

    # Strategy 2: fallback raw file downloads
    if not ok:
        print(f"    Trying fallback downloads...")
        all_ok = True
        for url, relpath in ds["fallback_urls"]:
            if not download_file(url, DATA_DIR / relpath):
                all_ok = False
        ok = all_ok

    n = count_data_files(target if target.exists() else DATA_DIR / ds["target_dir"])
    if ok:
        print(f"  -> OK: {name} ({n} data files)")
    else:
        print(f"  -> FAILED: {name}")
    return ok


def cmd_all():
    print("=" * 72)
    print("  PLLM-DY: Downloading ALL 4 Datasets")
    print("=" * 72)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    results = {}
    for name in DATASETS:
        results[name] = download_one(name)

    print("\n" + "=" * 72)
    print("  Download Summary")
    print("=" * 72)
    for name, ok in results.items():
        s = "OK" if ok else "FAILED"
        print(f"  [{s:>6}]  {name}")
    passed = sum(1 for v in results.values() if v)
    print(f"\n  {passed}/{len(results)} datasets downloaded.")
    if passed > 0:
        print(f"\n  Next steps:")
        print(f"    python experiments/calibrate_from_datasets.py")
        print(f"    python scripts/run_all.py")
    return all(results.values())


def cmd_status():
    print("\n  Dataset Status:")
    print(f"  {'Name':<20} {'Downloaded':<12} {'Data Files'}")
    print("  " + "-" * 55)
    for name, ds in DATASETS.items():
        target = DATA_DIR / ds["target_dir"]
        exists = target.exists()
        n = count_data_files(target) if exists else 0
        dl = "Yes" if exists else "No"
        print(f"  {name:<20} {dl:<12} {n}")
    all_ok = all((DATA_DIR / ds["target_dir"]).exists() for ds in DATASETS.values())
    print(f"\n  All ready: {'Yes' if all_ok else 'No'}")


def cmd_list():
    print("\n  Available datasets:\n")
    for name, ds in DATASETS.items():
        print(f"  {name}")
        print(f"    {ds['description']}")
        print(f"    Paper: {ds['paper_ref']}")
        print(f"    Repo:  {ds['url']}")
        print()


def main():
    parser = argparse.ArgumentParser(description="PLLM-DY Dataset Downloader")
    parser.add_argument("--all", action="store_true", help="Download ALL datasets")
    parser.add_argument("--dataset", type=str, help="Download one dataset by name")
    parser.add_argument("--status", action="store_true", help="Check download status")
    parser.add_argument("--list", action="store_true", help="List dataset details")
    args = parser.parse_args()

    if args.all:
        cmd_all()
    elif args.dataset:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        download_one(args.dataset)
    elif args.status:
        cmd_status()
    else:
        cmd_list()
        print("  Use --all to download everything, or --dataset <name> for one.")


if __name__ == "__main__":
    main()
