#!/usr/bin/env python3
"""
PLLM-DY: Run All Experiments
==============================
Master script that:
  1. Downloads all 4 datasets (if not present)
  2. Calibrates derivation functions from real data
  3. Runs all core experiments
  4. Generates all figures (including dataset-calibrated comparisons)

Usage:
    python scripts/run_all.py              # Full pipeline with datasets
    python scripts/run_all.py --no-download # Skip dataset download
"""

import sys
import os
import time
import argparse
from pathlib import Path

# Ensure project root is in path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
os.chdir(project_root)

from src.utils import print_header, get_results_dir, get_figures_dir


def run_experiment(name, module_path):
    """Run a single experiment module."""
    print(f"\n{'='*60}")
    print(f"  Running: {name}")
    print(f"{'='*60}")
    start = time.time()

    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(name, module_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if hasattr(mod, 'main'):
            mod.main()
        elapsed = time.time() - start
        print(f"\n  ✓ {name} completed in {elapsed:.1f}s")
        return True
    except Exception as e:
        elapsed = time.time() - start
        print(f"\n  ✗ {name} FAILED after {elapsed:.1f}s: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_datasets():
    """Check if datasets are already downloaded."""
    data_dir = project_root / "data"
    expected = ["jailbreakbench", "injecagent", "agentdojo", "dan_jailbreaks"]
    found = []
    missing = []
    for name in expected:
        if (data_dir / name).exists():
            found.append(name)
        else:
            missing.append(name)
    return found, missing


def main():
    parser = argparse.ArgumentParser(description="PLLM-DY Full Experiment Pipeline")
    parser.add_argument("--no-download", action="store_true",
                        help="Skip dataset download step")
    args = parser.parse_args()

    total_start = time.time()
    print_header("PLLM-DY: Complete Experiment Pipeline (with Datasets)")

    # Ensure output directories
    get_results_dir()
    get_figures_dir()

    results = {}

    # ─── Phase 1: Dataset Download ───
    if not args.no_download:
        found, missing = check_datasets()
        if missing:
            print(f"\n  Datasets missing: {', '.join(missing)}")
            print(f"  Downloading all 4 datasets...\n")
            success = run_experiment(
                "Download Datasets",
                str(project_root / "scripts" / "download_datasets.py")
            )
            results["Download Datasets"] = success
        else:
            print(f"\n  All 4 datasets already present: {', '.join(found)}")
            results["Download Datasets"] = True
    else:
        print(f"\n  Skipping dataset download (--no-download)")

    # ─── Phase 2: Core Experiments (default parameters) ───
    core_experiments = [
        ("Term Algebra Demo (§4.1-4.3)",
         "experiments/term_algebra_demo.py"),
        ("Taxonomy Mapping (§5)",
         "experiments/taxonomy_mapping.py"),
        ("Security Equivalence (§7.1)",
         "experiments/security_equivalence.py"),
        ("Case Study 1: IPI (§7.2)",
         "experiments/case_study_ipi.py"),
        ("Case Study 2: Cascade (§7.2)",
         "experiments/case_study_cascade.py"),
    ]

    for name, path in core_experiments:
        full_path = project_root / path
        success = run_experiment(name, str(full_path))
        results[name] = success

    # ─── Phase 3: Dataset Calibration ───
    found, _ = check_datasets()
    if found:
        success = run_experiment(
            "Calibrate from Datasets",
            str(project_root / "experiments" / "calibrate_from_datasets.py")
        )
        results["Calibrate from Datasets"] = success
    else:
        print(f"\n  Skipping calibration (no datasets found)")
        results["Calibrate from Datasets"] = False

    # ─── Phase 4: Generate All Figures ───
    success = run_experiment(
        "Generate All Figures",
        str(project_root / "scripts" / "generate_all_figures.py")
    )
    results["Generate All Figures"] = success

    # ─── Summary ───
    total_elapsed = time.time() - total_start
    print(f"\n{'='*60}")
    print(f"  EXPERIMENT SUMMARY")
    print(f"{'='*60}")
    for name, success in results.items():
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"  {status}  {name}")

    passed = sum(1 for v in results.values() if v)
    total = len(results)
    print(f"\n  {passed}/{total} steps passed")
    print(f"  Total time: {total_elapsed:.1f}s")
    print(f"\n  Results in: {get_results_dir()}")
    print(f"  Figures in: {get_figures_dir()}")

    # ProVerif instructions
    print(f"\n{'='*60}")
    print(f"  PROVERIF VERIFICATION (manual)")
    print(f"{'='*60}")
    print(f"  To verify the formal models, run:")
    print(f"    proverif proverif/protocol_centralized.pv")
    print(f"    proverif proverif/protocol_did.pv")
    print(f"    proverif proverif/protocol_did_pllmdy.pv")


if __name__ == "__main__":
    main()
