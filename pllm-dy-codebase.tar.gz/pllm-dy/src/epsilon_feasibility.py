"""
PLLM-DY ε-Feasible Derivability and Probabilistic Capability Set
=================================================================
Implements Definitions 4 and 5 (Section 4.3) and Theorem 2.

Definition 4: "t is ε-feasibly derivable from S, written S |-_ε t,
iff there exists a derivation sequence d_1,...,d_k such that
P(d_1) × ... × P(d_k) >= ε."

Definition 5: "Cap_ε(S)(t) = max over all derivation sequences from
S to t of the product of individual step probabilities."

Theorem 2: Monotonicity, trivial limit, and consistency with classical DY.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional
import numpy as np
from collections import defaultdict
import heapq

from .term_algebra import Term, KnowledgeSet
from .derivation_rules import DerivationStep, RuleType


@dataclass
class DerivationPath:
    """A complete derivation path from knowledge set S to a target term."""
    steps: List[DerivationStep]
    cumulative_probability: float
    target: Term

    @property
    def length(self) -> int:
        return len(self.steps)

    @property
    def rules_used(self) -> List[RuleType]:
        return [s.rule for s in self.steps]


class EpsilonFeasibilityChecker:
    """
    Checks ε-feasible derivability (Definition 4).
    
    Uses a priority-queue search over the derivation graph to find
    the highest-probability path from S to each target term.
    """

    def __init__(self, max_derivation_depth: int = 20):
        self.max_depth = max_derivation_depth

    def is_epsilon_feasible(self, path_prob: float, epsilon: float) -> bool:
        """
        Definition 4: S |-_ε t iff cumulative probability >= ε.
        
        "t is ε-feasibly derivable from S [...] if and only if there
        exists a derivation sequence d_1,...,d_k such that the
        cumulative success probability P(d_1) × ... × P(d_k) >= ε"
        """
        return path_prob >= epsilon

    def find_best_path(self, derivation_graph: Dict[Term, List[DerivationStep]],
                       source_terms: Set[Term],
                       target: Term) -> Optional[DerivationPath]:
        """
        Find the highest-probability derivation path from source terms to target.
        
        Uses a modified Dijkstra's algorithm on the derivation graph,
        maximizing the product of step probabilities (equivalently,
        minimizing the sum of -log(p)).
        
        Returns the best DerivationPath or None if target is unreachable.
        """
        # Priority queue: (-log_prob, term, path)
        # We minimize -log(cumulative_prob) = maximize cumulative_prob
        pq = []
        best_prob: Dict[Term, float] = {}

        for src in source_terms:
            best_prob[src] = 1.0
            heapq.heappush(pq, (0.0, id(src), src, []))

        while pq:
            neg_log_p, _, current, path = heapq.heappop(pq)
            current_prob = np.exp(-neg_log_p)

            if current == target:
                return DerivationPath(
                    steps=path,
                    cumulative_probability=current_prob,
                    target=target
                )

            if len(path) >= self.max_depth:
                continue

            # Skip if we already found a better path to this term
            if current in best_prob and current_prob < best_prob[current] * 0.99:
                continue

            # Explore outgoing derivation steps
            for step in derivation_graph.get(current, []):
                new_prob = current_prob * step.probability
                next_term = step.conclusion

                if next_term not in best_prob or new_prob > best_prob[next_term]:
                    best_prob[next_term] = new_prob
                    new_path = path + [step]
                    heapq.heappush(pq, (
                        -np.log(max(new_prob, 1e-300)),
                        id(next_term),
                        next_term,
                        new_path
                    ))

        return None  # Target unreachable


class ProbabilisticCapabilitySet:
    """
    Probabilistic Capability Set (Definition 5).
    
    "Cap_ε(S) : T_P → [0,1] defined as Cap_ε(S)(t) = max over all
    derivation sequences from S to t of the product of individual
    step probabilities."
    
    The ε-capability set is: {t ∈ T_P : Cap_ε(S)(t) >= ε}
    """

    def __init__(self):
        self._capabilities: Dict[Term, float] = {}
        self._paths: Dict[Term, DerivationPath] = {}

    def compute(self, derivation_graph: Dict[Term, List[DerivationStep]],
                source_terms: Set[Term],
                candidate_targets: Set[Term],
                max_depth: int = 20) -> None:
        """
        Compute Cap(S)(t) for all candidate target terms.
        
        This is the core computation of Definition 5:
        For each target t, find the maximum-probability derivation path
        from the source knowledge set S.
        """
        checker = EpsilonFeasibilityChecker(max_depth)

        for target in candidate_targets:
            if target in source_terms:
                # Already in knowledge set -> deterministically derivable
                self._capabilities[target] = 1.0
                self._paths[target] = DerivationPath([], 1.0, target)
            else:
                path = checker.find_best_path(
                    derivation_graph, source_terms, target
                )
                if path is not None:
                    self._capabilities[target] = path.cumulative_probability
                    self._paths[target] = path
                else:
                    self._capabilities[target] = 0.0

    def get_capability(self, term: Term) -> float:
        """Get Cap(S)(t) for a specific term."""
        return self._capabilities.get(term, 0.0)

    def get_path(self, term: Term) -> Optional[DerivationPath]:
        """Get the best derivation path to a term."""
        return self._paths.get(term)

    def epsilon_capability_set(self, epsilon: float) -> Set[Term]:
        """
        Return the ε-capability set: {t : Cap(S)(t) >= ε}.
        
        Theorem 2(i): "For any ε_1 <= ε_2, the ε_2-capability set
        is a subset of the ε_1-capability set."
        """
        return {t for t, p in self._capabilities.items() if p >= epsilon}

    def capability_distribution(self) -> Dict[Term, float]:
        """Return full capability mapping."""
        return dict(self._capabilities)

    @property
    def size(self) -> int:
        return len(self._capabilities)


# ============================================================================
# Theorem 2 Verification (Section 4.3)
# ============================================================================

def verify_theorem_2(cap_set: ProbabilisticCapabilitySet,
                     epsilon_values: List[float]) -> Dict[str, bool]:
    """
    Verify Theorem 2 (Monotonicity and Consistency).
    
    (i) For ε_1 <= ε_2, Cap_ε2 ⊆ Cap_ε1
    (ii) As ε → 0, Cap_ε → T_P (everything becomes feasible)
    (iii) When all probabilities are 0 or 1, reduces to classical DY
    
    Returns dict of {property_name: verified_bool}.
    """
    results = {}

    # Sort epsilons
    sorted_eps = sorted(epsilon_values)

    # (i) Monotonicity: larger ε => smaller or equal capability set
    monotonic = True
    prev_set = None
    for eps in sorted_eps:
        current_set = cap_set.epsilon_capability_set(eps)
        if prev_set is not None:
            if not current_set.issubset(prev_set):
                monotonic = False
                break
        prev_set = current_set
    results["monotonicity"] = monotonic

    # (ii) Trivial limit: smallest ε should give largest set
    smallest_eps_set = cap_set.epsilon_capability_set(min(sorted_eps))
    largest_eps_set = cap_set.epsilon_capability_set(max(sorted_eps))
    results["trivial_limit"] = len(smallest_eps_set) >= len(largest_eps_set)

    # (iii) Consistency: check that deterministic derivations (p=1.0)
    # are in the capability set for ALL ε ∈ (0, 1]
    deterministic_terms = {
        t for t, p in cap_set.capability_distribution().items() if p == 1.0
    }
    consistent = True
    for eps in sorted_eps:
        if eps > 0:
            eps_set = cap_set.epsilon_capability_set(eps)
            if not deterministic_terms.issubset(eps_set):
                consistent = False
                break
    results["classical_consistency"] = consistent

    return results


# ============================================================================
# Attack Surface Parameter (Section 4.3)
# ============================================================================

def compute_attack_surface(theta_params: Dict[str, float],
                          attack_functions: List[callable],
                          num_samples: int = 1000,
                          rng: np.random.Generator = None) -> float:
    """
    Compute α(θ): the attack surface parameter.
    
    Section 4.3: "α(θ) = max_{π_adv} f(τ, L, φ, π_adv)"
    
    "The attack surface parameter for an LLM agent with parameters θ
    is the maximum probability that a single adversarial derivation
    step succeeds against that agent, taken over the space of
    adversarial prompts."
    
    We approximate by sampling adversarial prompts and computing
    the maximum success probability across all attack functions.
    """
    if rng is None:
        rng = np.random.default_rng(42)

    from .derivation_rules import LLMParameters, AttackParameters

    theta = LLMParameters(
        agent_id="surface_test",
        temperature=theta_params.get("temperature", 0.7),
        alignment_robustness=theta_params.get("alignment_robustness", 0.7)
    )

    max_prob = 0.0

    for _ in range(num_samples):
        # Sample random attack parameters
        attack = AttackParameters(
            adversarial_content_ratio=rng.uniform(0.01, 1.0),
            retrieval_probability=rng.uniform(0.1, 0.9),
            trust_level=rng.uniform(0.1, 0.95),
            semantic_similarity=rng.uniform(0.5, 1.0)
        )

        for func in attack_functions:
            try:
                prob = func(theta, attack)
            except TypeError:
                # Some functions take different args
                try:
                    prob = func(theta)
                except Exception:
                    prob = func(attack)
            max_prob = max(max_prob, prob)

    return max_prob
