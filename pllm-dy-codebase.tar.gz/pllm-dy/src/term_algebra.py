"""
PLLM-DY Term Algebra Implementation
====================================
Implements Definition 1 (Section 4.1) of the paper:
"The PLLM-DY term algebra T_P extends T_DY with LLM agent terms,
 tool terms, and probabilistic derivation terms."

The standard DY term algebra T_DY is defined over:
  - Names N, Nonces R, Keys K
  - Function symbols F = {enc, dec, sign, verify, hash, pair, fst, snd}

T_P extends this with:
  - llm(theta, ctx, prompt)    : LLM agent terms
  - tool(name, input, output)  : Tool invocation terms
  - prob(t, D)                 : Probabilistic derivation terms
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List, Set, FrozenSet, Tuple
from enum import Enum, auto
import hashlib
import uuid


# ============================================================================
# Base Term Types (Standard Dolev-Yao)
# ============================================================================

class TermType(Enum):
    """Classification of terms in T_DY and T_P."""
    # T_DY base types
    NAME = auto()
    NONCE = auto()
    SECRET_KEY = auto()
    PUBLIC_KEY = auto()
    # T_DY compound types
    ENCRYPTION = auto()
    SIGNATURE = auto()
    HASH = auto()
    PAIR = auto()
    # T_P extensions (Definition 1)
    LLM_AGENT = auto()
    TOOL = auto()
    TOOL_OUTPUT = auto()
    PROBABILISTIC = auto()
    # Derived types
    ACTION = auto()
    BELIEF = auto()
    CONTEXT = auto()
    PROMPT = auto()


@dataclass(frozen=True)
class Term:
    """
    Base class for all terms in the PLLM-DY term algebra T_P.

    Corresponds to Definition 1, Section 4.1:
    "Let T_DY be the standard Dolev-Yao term algebra... The PLLM-DY
     term algebra T_P extends T_DY."

    Terms are immutable (frozen) for use in sets and as dict keys.
    """
    term_type: TermType
    value: str
    subterms: Tuple[Term, ...] = field(default_factory=tuple)

    def __str__(self) -> str:
        if not self.subterms:
            return self.value
        sub_str = ", ".join(str(s) for s in self.subterms)
        return f"{self.value}({sub_str})"

    def __repr__(self) -> str:
        return self.__str__()

    @property
    def is_atomic(self) -> bool:
        """Atomic terms have no subterms."""
        return len(self.subterms) == 0

    @property
    def all_subterms(self) -> Set[Term]:
        """Recursively collect all subterms (including self)."""
        result = {self}
        for st in self.subterms:
            result |= st.all_subterms
        return result

    @property
    def depth(self) -> int:
        """Nesting depth of the term."""
        if self.is_atomic:
            return 0
        return 1 + max(st.depth for st in self.subterms)


# ============================================================================
# T_DY Term Constructors (Standard Dolev-Yao)
# ============================================================================

def Name(name: str) -> Term:
    """Agent or entity name. Part of N in T_DY."""
    return Term(TermType.NAME, name)


def Nonce(label: str = None) -> Term:
    """Fresh nonce. Part of R in T_DY."""
    if label is None:
        label = f"n_{uuid.uuid4().hex[:8]}"
    return Term(TermType.NONCE, label)


def SecretKey(owner: str) -> Term:
    """Secret (private) key. Part of K in T_DY."""
    return Term(TermType.SECRET_KEY, f"sk_{owner}")


def PublicKey(owner: str) -> Term:
    """
    Public key derived from secret key.
    In DY: pk(sk_A) is a function symbol application.
    """
    return Term(TermType.PUBLIC_KEY, f"pk_{owner}")


def Enc(plaintext: Term, key: Term) -> Term:
    """
    Symmetric or asymmetric encryption: enc(m, k).
    DY assumption: dec(enc(m,k), k) = m, and this is the ONLY way to recover m.
    """
    return Term(TermType.ENCRYPTION, "enc", (plaintext, key))


def Dec(ciphertext: Term, key: Term) -> Term:
    """
    Decryption attempt: dec(c, k).
    Succeeds iff c = enc(m, k) for some m, yielding m.
    """
    # In symbolic model, check structure
    if (ciphertext.term_type == TermType.ENCRYPTION
            and len(ciphertext.subterms) == 2
            and ciphertext.subterms[1] == key):
        return ciphertext.subterms[0]  # Successfully decrypt
    # Cannot decrypt - return opaque term
    return Term(TermType.ENCRYPTION, "dec", (ciphertext, key))


def Sign(message: Term, secret_key: Term) -> Term:
    """Digital signature: sign(m, sk)."""
    return Term(TermType.SIGNATURE, "sign", (message, secret_key))


def Verify(signature: Term, public_key: Term) -> Optional[Term]:
    """
    Signature verification: verify(sign(m, sk), pk(sk)) = m.
    Returns the signed message if verification succeeds, None otherwise.
    """
    if (signature.term_type == TermType.SIGNATURE
            and len(signature.subterms) == 2):
        msg, sk = signature.subterms
        # Check key correspondence: pk_X corresponds to sk_X
        expected_pk = PublicKey(sk.value.replace("sk_", ""))
        if public_key == expected_pk:
            return msg
    return None


def Hash(message: Term) -> Term:
    """Cryptographic hash: hash(m). One-way in DY."""
    return Term(TermType.HASH, "hash", (message,))


def Pair(left: Term, right: Term) -> Term:
    """Pairing: pair(t1, t2)."""
    return Term(TermType.PAIR, "pair", (left, right))


def Fst(pair_term: Term) -> Optional[Term]:
    """First projection: fst(pair(t1, t2)) = t1."""
    if pair_term.term_type == TermType.PAIR and len(pair_term.subterms) == 2:
        return pair_term.subterms[0]
    return None


def Snd(pair_term: Term) -> Optional[Term]:
    """Second projection: snd(pair(t1, t2)) = t2."""
    if pair_term.term_type == TermType.PAIR and len(pair_term.subterms) == 2:
        return pair_term.subterms[1]
    return None


# ============================================================================
# T_P Extension Constructors (PLLM-DY - Definition 1)
# ============================================================================

def LLMAgent(agent_id: str, temperature: float, context_length: int,
             alignment: float) -> Term:
    """
    LLM agent term: llm(theta, ctx, prompt).
    
    Definition 1(i): "LLM agent terms llm(theta, ctx, prompt) representing
    an agent with parameters theta processing context ctx under prompt."
    
    Parameters encode theta = (temperature, context_length, alignment).
    """
    theta = Term(TermType.NAME, f"theta_{agent_id}")
    return Term(TermType.LLM_AGENT, f"llm_{agent_id}", (theta,))


def ToolInvocation(tool_name: str, input_term: Term, output_term: Term) -> Term:
    """
    Tool term: tool(name, input, output).
    
    Definition 1(ii): "tool terms tool(name, input, output) representing
    tool invocations."
    """
    name_term = Term(TermType.NAME, tool_name)
    return Term(TermType.TOOL, "tool", (name_term, input_term, output_term))


def ToolOutput(tool_name: str, content: str) -> Term:
    """Raw tool output before processing by an agent."""
    return Term(TermType.TOOL_OUTPUT, f"output_{tool_name}_{content[:16]}")


def ProbabilisticTerm(base_term: Term, distribution_id: str) -> Term:
    """
    Probabilistic derivation term: prob(t, D).
    
    Definition 1(iii): "probabilistic derivation terms prob(t, D) where
    t is a term and D is a probability distribution over T_P."
    """
    dist = Term(TermType.NAME, distribution_id)
    return Term(TermType.PROBABILISTIC, "prob", (base_term, dist))


def Action(agent_id: str, action_desc: str) -> Term:
    """Agent action term: action(A_i, a)."""
    return Term(TermType.ACTION, f"action_{agent_id}_{action_desc}")


def Belief(agent_id: str, belief_desc: str) -> Term:
    """Agent belief term: belief(A_i, phi)."""
    return Term(TermType.BELIEF, f"belief_{agent_id}_{belief_desc}")


def Context(content_terms: List[Term]) -> Term:
    """Context term aggregating multiple inputs."""
    return Term(TermType.CONTEXT, "ctx", tuple(content_terms))


def Prompt(content: str, is_adversarial: bool = False) -> Term:
    """Prompt term (possibly adversarial)."""
    prefix = "adv_prompt" if is_adversarial else "prompt"
    return Term(TermType.PROMPT, f"{prefix}_{content[:20]}")


# ============================================================================
# Knowledge Set (Adversary State)
# ============================================================================

class KnowledgeSet:
    """
    The adversary's knowledge set S in PLLM-DY.
    
    In classical DY: S is a set of terms, and S |- t means t is derivable
    from S using derivation rules.
    
    In PLLM-DY: derivability becomes probabilistic (Definition 2).
    This class manages the base knowledge set; probabilistic derivation
    is handled by DerivationEngine (derivation_rules.py).
    """

    def __init__(self, initial_terms: Set[Term] = None):
        self._terms: Set[Term] = set(initial_terms) if initial_terms else set()
        self._derivation_history: List[Tuple[str, Term]] = []

    def add(self, term: Term, reason: str = "initial") -> None:
        """Add a term to the knowledge set."""
        if term not in self._terms:
            self._terms.add(term)
            self._derivation_history.append((reason, term))

    def contains(self, term: Term) -> bool:
        """Check if term is in the knowledge set."""
        return term in self._terms

    @property
    def terms(self) -> FrozenSet[Term]:
        """Immutable view of current terms."""
        return frozenset(self._terms)

    @property
    def size(self) -> int:
        return len(self._terms)

    @property
    def history(self) -> List[Tuple[str, Term]]:
        return list(self._derivation_history)

    def classical_closure(self) -> 'KnowledgeSet':
        """
        Compute classical DY closure: apply all deterministic derivation
        rules until no new terms can be derived.
        
        This implements the standard DY deduction system:
        - Pairing: S |- t1, S |- t2  =>  S |- pair(t1, t2)
        - Projection: S |- pair(t1, t2)  =>  S |- t1, S |- t2
        - Encryption: S |- m, S |- k  =>  S |- enc(m, k)
        - Decryption: S |- enc(m, k), S |- k  =>  S |- m
        - Signing: S |- m, S |- sk  =>  S |- sign(m, sk)
        - Verification: S |- sign(m, sk), S |- pk(sk)  =>  S |- m
        - Hashing: S |- m  =>  S |- hash(m)
        """
        changed = True
        closed = KnowledgeSet(self._terms.copy())

        while changed:
            changed = False
            new_terms = set()
            current = list(closed._terms)

            for t in current:
                # Projection from pairs
                if t.term_type == TermType.PAIR and len(t.subterms) == 2:
                    for st in t.subterms:
                        if st not in closed._terms:
                            new_terms.add(st)

                # Decryption: if we have enc(m,k) and k
                if t.term_type == TermType.ENCRYPTION and len(t.subterms) == 2:
                    _, key = t.subterms
                    if closed.contains(key):
                        plaintext = t.subterms[0]
                        if plaintext not in closed._terms:
                            new_terms.add(plaintext)

                # Signature verification
                if t.term_type == TermType.SIGNATURE and len(t.subterms) == 2:
                    msg, sk = t.subterms
                    pk = PublicKey(sk.value.replace("sk_", ""))
                    if closed.contains(pk):
                        if msg not in closed._terms:
                            new_terms.add(msg)

            for nt in new_terms:
                closed.add(nt, "classical_closure")
                changed = True

        return closed

    def __repr__(self) -> str:
        return f"KnowledgeSet(|S|={self.size})"
