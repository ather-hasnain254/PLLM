"""
PLLM-DY Multi-Agent LLM System Simulator
==========================================
Simulates a multi-agent LLM system under the PLLM-DY threat model
(Section 3). Provides the infrastructure for running the experimental
evaluations in Sections 7.1 and 7.2.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional
import numpy as np
import yaml
from pathlib import Path

from .term_algebra import KnowledgeSet, Term, Name, Nonce, SecretKey, PublicKey
from .derivation_rules import LLMParameters, AttackParameters, DerivationEngine
from .attack_graph import AttackGraph, AgentNode, CommunicationChannel


def load_config(config_path: str = None) -> Dict:
    """Load empirical parameters from YAML config."""
    if config_path is None:
        config_path = Path(__file__).parent.parent / "config" / "empirical_parameters.yaml"
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


class MultiAgentSystem:
    """
    A simulated multi-agent LLM system.
    
    Section 3: "We consider a multi-agent LLM system consisting of
    n agents A = {A_1, ..., A_n}, each backed by an LLM with
    parameters θ_i."
    """

    def __init__(self, config: Dict = None):
        self.config = config or load_config()
        self.agents: Dict[str, AgentNode] = {}
        self.channels: List[CommunicationChannel] = []
        self.attack_graph = AttackGraph()

    def create_agent(self, agent_id: str, model_type: str = "gpt4",
                     tools: List[str] = None) -> AgentNode:
        """Create an LLM agent with parameters from config."""
        model_config = self.config.get("llm_models", {}).get(model_type, {})

        params = LLMParameters(
            agent_id=agent_id,
            temperature=model_config.get("default_temperature", 0.7),
            context_length=model_config.get("max_context_length", 128000),
            alignment_robustness=model_config.get("alignment_robustness", 0.7),
        )
        agent = AgentNode(
            agent_id=agent_id,
            params=params,
            tools=tools or ["web_search", "code_exec"],
        )
        self.agents[agent_id] = agent
        self.attack_graph.add_agent(agent)
        return agent

    def connect_agents(self, source_id: str, target_id: str,
                       trust_level: float = 0.5,
                       bidirectional: bool = True) -> None:
        """Establish a communication channel between agents."""
        ch = CommunicationChannel(source_id, target_id, trust_level)
        self.channels.append(ch)
        self.attack_graph.add_channel(ch)

        if bidirectional:
            ch_rev = CommunicationChannel(target_id, source_id, trust_level)
            self.channels.append(ch_rev)
            self.attack_graph.add_channel(ch_rev)

    def create_default_system(self, num_agents: int = 5) -> None:
        """
        Create a default multi-agent system matching the paper's
        case studies (Section 7.2).
        """
        models = ["gpt4", "gpt35", "llama2_70b", "claude", "gpt4"]
        trust = self.config.get("multi_agent", {}).get("trust_levels", {})

        for i in range(num_agents):
            model = models[i % len(models)]
            tools = ["web_search", "code_exec", "file_read"]
            self.create_agent(f"A{i+1}", model, tools)

        # Create communication graph
        # High trust within task groups
        for i in range(min(3, num_agents)):
            for j in range(i + 1, min(3, num_agents)):
                self.connect_agents(
                    f"A{i+1}", f"A{j+1}",
                    trust.get("high", 0.85)
                )

        # Medium trust between groups
        if num_agents > 3:
            for i in range(3):
                for j in range(3, num_agents):
                    self.connect_agents(
                        f"A{i+1}", f"A{j+1}",
                        trust.get("medium", 0.50)
                    )

    def build_attack_graph(self) -> None:
        """Build the full PLLM-DY attack graph."""
        initial_knowledge = KnowledgeSet()
        # Adversary knows public keys
        for agent_id in self.agents:
            initial_knowledge.add(PublicKey(agent_id))
        self.attack_graph.build_graph(initial_knowledge)

    def simulate_cascade(self, entry_agent: str, chain: List[str],
                        initial_prob: float,
                        num_trials: int = 10000,
                        rng: np.random.Generator = None) -> Dict:
        """
        Monte Carlo simulation of a cascade attack (Case Study 2).
        
        Section 7.2: "The adversary compromises agent A_1 and propagates
        influence through a chain A_1 → A_2 → A_3 using R4."
        """
        if rng is None:
            seed = self.config.get("simulation", {}).get("random_seed", 42)
            rng = np.random.default_rng(seed)

        successes = 0
        chain_probs = []

        for _ in range(num_trials):
            # Step 1: Initial compromise
            if rng.random() > initial_prob:
                continue

            # Step 2: Propagate along chain
            chain_success = True
            trial_prob = initial_prob

            for i in range(len(chain) - 1):
                src = chain[i]
                tgt = chain[i + 1]

                # Find trust level
                trust = 0.5
                for ch in self.channels:
                    if ch.source_id == src and ch.target_id == tgt:
                        trust = ch.trust_level
                        break

                # Compute R4 probability
                attack_params = AttackParameters(trust_level=trust)
                source_params = self.agents[src].params
                target_params = self.agents[tgt].params

                engine = DerivationEngine()
                step = engine.apply_r4(
                    KnowledgeSet(), source_params, target_params, attack_params
                )

                trial_prob *= step.probability

                if rng.random() > step.probability:
                    chain_success = False
                    break

            if chain_success:
                successes += 1
                chain_probs.append(trial_prob)

        empirical_prob = successes / num_trials
        theoretical_prob = self.attack_graph.compute_cascade_probability(
            chain, initial_prob
        )

        return {
            "chain": chain,
            "num_trials": num_trials,
            "successes": successes,
            "empirical_probability": empirical_prob,
            "theoretical_probability": theoretical_prob,
            "confidence_interval_95": 1.96 * np.sqrt(
                empirical_prob * (1 - empirical_prob) / num_trials
            ) if num_trials > 0 else 0,
        }
