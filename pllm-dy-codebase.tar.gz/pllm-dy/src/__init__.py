# PLLM-DY: Probabilistic Dolev-Yao Attacker Model for Multi-Agent LLM Systems
__version__ = "1.0.0"
