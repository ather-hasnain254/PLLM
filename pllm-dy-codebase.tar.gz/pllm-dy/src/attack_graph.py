"""
PLLM-DY Attack Graph Construction and Analysis
================================================
Builds and analyzes attack graphs over multi-agent LLM systems.

An attack graph represents all possible derivation paths from the
adversary's initial knowledge to target compromise states.
Nodes are terms (agent states, actions, beliefs).
Edges are derivation rules (R1-R5 and classical DY) with probabilities.

Used for:
  - ε-feasibility analysis (Section 4.3)
  - Cascade attack analysis (Section 7.2, Case Study 2)
  - Taxonomy mapping verification (Section 5)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional
import numpy as np
import networkx as nx

from .term_algebra import Term, TermType, KnowledgeSet, Action, Prompt, ToolOutput
from .derivation_rules import (
    DerivationStep, DerivationEngine, RuleType,
    LLMParameters, AttackParameters
)
from .epsilon_feasibility import (
    ProbabilisticCapabilitySet, EpsilonFeasibilityChecker, DerivationPath
)


@dataclass
class AgentNode:
    """An agent in the multi-agent system."""
    agent_id: str
    params: LLMParameters
    tools: List[str] = field(default_factory=list)
    is_compromised: bool = False


@dataclass
class CommunicationChannel:
    """A communication channel between two agents."""
    source_id: str
    target_id: str
    trust_level: float
    authenticated: bool = True


class AttackGraph:
    """
    Attack graph for a multi-agent LLM system under PLLM-DY.
    
    Encodes all reachable attack states and the probabilities
    of reaching them, supporting the ε-bounded analysis of
    Sections 4.3 and 7.2.
    """

    def __init__(self):
        self.agents: Dict[str, AgentNode] = {}
        self.channels: List[CommunicationChannel] = []
        self.derivation_graph: Dict[Term, List[DerivationStep]] = {}
        self.engine = DerivationEngine()
        self._nx_graph: Optional[nx.DiGraph] = None

    def add_agent(self, agent: AgentNode) -> None:
        self.agents[agent.agent_id] = agent

    def add_channel(self, channel: CommunicationChannel) -> None:
        self.channels.append(channel)

    def build_graph(self, initial_knowledge: KnowledgeSet,
                    attack_vectors: List[str] = None) -> None:
        """
        Construct the full attack graph from initial knowledge.
        
        For each agent and each applicable rule (R1-R5), creates
        derivation steps with associated probabilities.
        """
        if attack_vectors is None:
            attack_vectors = ["dpi", "ipi", "context", "cascade", "semantic"]

        self.derivation_graph.clear()

        for agent_id, agent in self.agents.items():
            theta = agent.params

            # R1: Direct Prompt Injection
            if "dpi" in attack_vectors:
                adv_prompt = Prompt("dpi_payload", is_adversarial=True)
                step = self.engine.apply_r1(initial_knowledge, theta, adv_prompt)
                self.derivation_graph.setdefault(adv_prompt, []).append(step)

            # R2: Indirect Prompt Injection via each tool
            if "ipi" in attack_vectors:
                for tool_name in agent.tools:
                    corrupted = ToolOutput(tool_name, "adversarial_content")
                    for ratio in [0.05, 0.1, 0.2, 0.5]:
                        attack_params = AttackParameters(
                            adversarial_content_ratio=ratio,
                            retrieval_probability=0.3
                        )
                        stage1, stage2 = self.engine.apply_r2(
                            initial_knowledge, theta, tool_name,
                            corrupted, attack_params
                        )
                        self.derivation_graph.setdefault(
                            corrupted, []
                        ).append(stage1)
                        self.derivation_graph.setdefault(
                            stage1.conclusion, []
                        ).append(stage2)

            # R3: Context Poisoning
            if "context" in attack_vectors:
                for ratio in [0.1, 0.3, 0.5]:
                    poisoned = Term(TermType.CONTEXT, f"poisoned_ctx_{agent_id}")
                    attack_params = AttackParameters(
                        adversarial_content_ratio=ratio
                    )
                    step = self.engine.apply_r3(
                        initial_knowledge, theta, poisoned, attack_params
                    )
                    self.derivation_graph.setdefault(poisoned, []).append(step)

        # R4: Agent Cascade (depends on communication topology)
        if "cascade" in attack_vectors:
            for channel in self.channels:
                if channel.source_id in self.agents and channel.target_id in self.agents:
                    source = self.agents[channel.source_id]
                    target = self.agents[channel.target_id]
                    attack_params = AttackParameters(
                        trust_level=channel.trust_level
                    )
                    step = self.engine.apply_r4(
                        initial_knowledge, source.params, target.params,
                        attack_params
                    )
                    # Connect compromise of source to influence on target
                    compromise_term = Action(source.agent_id, "compromised")
                    self.derivation_graph.setdefault(
                        compromise_term, []
                    ).append(step)

    def compute_cascade_probability(self, chain: List[str],
                                    initial_compromise_prob: float,
                                    trust_levels: List[float] = None) -> float:
        """
        Compute the probability of a cascade attack along a chain of agents.
        
        Section 7.2, Case Study 2:
        "p_cascade = p_compromise_1 × p_4(A_1→A_2) × p_4(A_2→A_3)"
        """
        if len(chain) < 2:
            return initial_compromise_prob

        if trust_levels is None:
            # Default: look up from channels
            trust_levels = []
            for i in range(len(chain) - 1):
                trust = 0.5  # default
                for ch in self.channels:
                    if ch.source_id == chain[i] and ch.target_id == chain[i + 1]:
                        trust = ch.trust_level
                        break
                trust_levels.append(trust)

        prob = initial_compromise_prob
        for i in range(len(chain) - 1):
            source = self.agents.get(chain[i])
            target = self.agents.get(chain[i + 1])
            if source is None or target is None:
                return 0.0
            attack_params = AttackParameters(trust_level=trust_levels[i])
            step = self.engine.apply_r4(
                KnowledgeSet(), source.params, target.params, attack_params
            )
            prob *= step.probability

        return prob

    def to_networkx(self) -> nx.DiGraph:
        """Convert to NetworkX graph for analysis and visualization."""
        G = nx.DiGraph()

        for source_term, steps in self.derivation_graph.items():
            src_str = str(source_term)
            G.add_node(src_str, term_type=source_term.term_type.name)

            for step in steps:
                tgt_str = str(step.conclusion)
                G.add_node(tgt_str,
                          term_type=step.conclusion.term_type.name)
                G.add_edge(src_str, tgt_str,
                          probability=step.probability,
                          rule=step.rule.name,
                          description=step.description)

        self._nx_graph = G
        return G

    def find_all_paths_to(self, target_agent_id: str,
                          max_length: int = 5) -> List[Tuple[List[str], float]]:
        """
        Find all attack paths reaching a target agent, with probabilities.
        Returns list of (path, probability) tuples.
        """
        G = self.to_networkx() if self._nx_graph is None else self._nx_graph
        target_nodes = [n for n in G.nodes if target_agent_id in n
                       and "action" in n.lower()]

        results = []
        for source in G.nodes:
            if "prompt" in source.lower() or "corrupt" in source.lower():
                for target in target_nodes:
                    try:
                        for path in nx.all_simple_paths(G, source, target,
                                                        cutoff=max_length):
                            # Compute path probability
                            prob = 1.0
                            for i in range(len(path) - 1):
                                edge_data = G.edges[path[i], path[i + 1]]
                                prob *= edge_data.get("probability", 1.0)
                            if prob > 0:
                                results.append((path, prob))
                    except nx.NetworkXError:
                        continue

        return sorted(results, key=lambda x: -x[1])

    def get_statistics(self) -> Dict:
        """Get attack graph statistics."""
        G = self.to_networkx() if self._nx_graph is None else self._nx_graph
        return {
            "num_nodes": G.number_of_nodes(),
            "num_edges": G.number_of_edges(),
            "num_agents": len(self.agents),
            "num_channels": len(self.channels),
            "avg_out_degree": (np.mean([d for _, d in G.out_degree()])
                              if G.number_of_nodes() > 0 else 0),
        }
