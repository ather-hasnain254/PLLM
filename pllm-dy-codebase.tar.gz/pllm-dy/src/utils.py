"""
PLLM-DY Shared Utilities
=========================
"""
import json
import os
from pathlib import Path
from datetime import datetime
from typing import Any, Dict


def get_project_root() -> Path:
    """Get the project root directory."""
    return Path(__file__).parent.parent


def get_results_dir() -> Path:
    d = get_project_root() / "results"
    d.mkdir(exist_ok=True)
    return d


def get_figures_dir() -> Path:
    d = get_project_root() / "figures"
    d.mkdir(exist_ok=True)
    return d


def save_results(data: Dict[str, Any], filename: str) -> Path:
    """Save experiment results to JSON."""
    filepath = get_results_dir() / filename
    # Convert numpy types for JSON serialization
    def convert(obj):
        import numpy as np
        if isinstance(obj, (np.integer,)):
            return int(obj)
        elif isinstance(obj, (np.floating,)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, set):
            return list(obj)
        return obj

    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2, default=convert)
    print(f"  Results saved to: {filepath}")
    return filepath


def load_results(filename: str) -> Dict:
    filepath = get_results_dir() / filename
    with open(filepath, 'r') as f:
        return json.load(f)


def print_header(title: str) -> None:
    sep = "=" * 70
    print(f"\n{sep}")
    print(f"  {title}")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{sep}\n")


def print_section(title: str) -> None:
    print(f"\n--- {title} ---")
