"""
PLLM-DY Protocol Implementations
==================================
Implements Protocol 1 (Centralized Authority) and Protocol 2 (DID-Based)
as described in Section 6.1 of the paper.

These are symbolic protocol implementations used for security analysis,
not production cryptographic code.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from enum import Enum, auto

from src.term_algebra import (
    Term, TermType, KnowledgeSet, Name, Nonce, SecretKey, PublicKey,
    Enc, Dec, Sign, Verify, Pair, Hash
)
from src.derivation_rules import LLMParameters


class ProtocolType(Enum):
    CENTRALIZED = auto()
    DECENTRALIZED_DID = auto()


@dataclass
class ProtocolMessage:
    """A message in a protocol execution."""
    sender: str
    receiver: str
    content: Term
    session_id: str
    step: int
    is_authenticated: bool = False


@dataclass
class ProtocolSession:
    """A complete protocol session between two agents."""
    session_id: str
    initiator: str
    responder: str
    messages: List[ProtocolMessage] = field(default_factory=list)
    completed: bool = False
    authenticated: bool = False
    secret_preserved: bool = True


class CentralizedProtocol:
    """
    Protocol 1: Centralized Authority (SAGA-style).
    
    Section 6.1: "A trusted authority CA issues session tokens to agents.
    Agent A_i authenticates by presenting credentials to CA, receiving
    a signed session token σ_i = sign(sk_CA, (A_i, session_id, timestamp)).
    Inter-agent messages carry these tokens:
    msg = enc(pk_j, (payload, σ_i))."
    """

    def __init__(self):
        self.ca_sk = SecretKey("CA")
        self.ca_pk = PublicKey("CA")
        self.agent_keys: Dict[str, Tuple[Term, Term]] = {}
        self.sessions: Dict[str, ProtocolSession] = {}
        self.issued_tokens: Dict[str, Term] = {}

    def register_agent(self, agent_id: str) -> None:
        """Register an agent with the CA."""
        sk = SecretKey(agent_id)
        pk = PublicKey(agent_id)
        self.agent_keys[agent_id] = (sk, pk)

    def issue_session_token(self, agent_id: str, session_id: str) -> Term:
        """
        CA issues signed session token.
        σ_i = sign(sk_CA, (A_i, session_id, timestamp))
        """
        agent_name = Name(agent_id)
        session_name = Name(session_id)
        timestamp = Nonce(f"ts_{session_id}")
        payload = Pair(agent_name, Pair(session_name, timestamp))
        token = Sign(payload, self.ca_sk)
        self.issued_tokens[f"{agent_id}_{session_id}"] = token
        return token

    def create_message(self, sender: str, receiver: str,
                       payload: Term, session_id: str,
                       step: int) -> ProtocolMessage:
        """
        Create authenticated message: msg = enc(pk_j, (payload, σ_i))
        """
        token = self.issued_tokens.get(f"{sender}_{session_id}")
        if token is None:
            token = self.issue_session_token(sender, session_id)

        _, receiver_pk = self.agent_keys.get(receiver, (None, PublicKey(receiver)))
        inner = Pair(payload, token)
        encrypted = Enc(inner, receiver_pk)

        return ProtocolMessage(
            sender=sender, receiver=receiver,
            content=encrypted, session_id=session_id,
            step=step, is_authenticated=True
        )

    def verify_message(self, msg: ProtocolMessage) -> Tuple[bool, Optional[Term]]:
        """
        Receiving agent verifies:
        1. Decrypt with own key
        2. Verify CA signature on token
        """
        receiver_sk, _ = self.agent_keys.get(msg.receiver, (None, None))
        if receiver_sk is None:
            return False, None

        # Decrypt
        decrypted = Dec(msg.content, receiver_sk)
        if decrypted.term_type != TermType.PAIR:
            return False, None

        # Extract payload and token
        payload = decrypted.subterms[0] if len(decrypted.subterms) > 0 else None
        token = decrypted.subterms[1] if len(decrypted.subterms) > 1 else None

        # Verify CA signature
        if token is not None:
            verified = Verify(token, self.ca_pk)
            if verified is not None:
                return True, payload

        return False, None

    def run_session(self, initiator: str, responder: str,
                    payload: Term) -> ProtocolSession:
        """Execute a complete protocol session."""
        session_id = f"sess_{initiator}_{responder}"
        session = ProtocolSession(session_id, initiator, responder)

        # Step 1: Initiator sends to responder
        msg1 = self.create_message(initiator, responder, payload,
                                   session_id, step=1)
        session.messages.append(msg1)

        # Step 2: Responder verifies and responds
        auth, recv_payload = self.verify_message(msg1)
        if auth and recv_payload:
            response = Name(f"ack_{session_id}")
            msg2 = self.create_message(responder, initiator, response,
                                       session_id, step=2)
            session.messages.append(msg2)

            # Step 3: Initiator verifies response
            auth2, _ = self.verify_message(msg2)
            session.completed = auth2
            session.authenticated = auth and auth2

        self.sessions[session_id] = session
        return session

    @property
    def protocol_type(self) -> ProtocolType:
        return ProtocolType.CENTRALIZED

    def get_security_properties(self) -> Dict[str, bool]:
        """Check security properties (corresponds to Theorems 4-5)."""
        all_authenticated = all(s.authenticated for s in self.sessions.values())
        all_secret = all(s.secret_preserved for s in self.sessions.values())
        return {
            "authentication": all_authenticated,
            "secrecy": all_secret,
            "trust_assumption": "Trusted CA",
            "single_point_of_failure": True,
        }


class DecentralizedDIDProtocol:
    """
    Protocol 2: Decentralized DID-Based.
    
    Section 6.1: "Each agent possesses a DID document did:method:agent_i
    containing its public key pk_i. Agents authenticate via DIDComm v2:
    msg = JWE(pk_j, sign(sk_i, (payload, nonce, did_i, did_j)))."
    
    "Following the formal analysis of Badertscher et al. [46], we adopt
    their optimized construction addressing identity leakage."
    """

    def __init__(self):
        self.did_registry: Dict[str, Term] = {}  # DID -> public key
        self.agent_keys: Dict[str, Tuple[Term, Term]] = {}
        self.sessions: Dict[str, ProtocolSession] = {}

    def register_did(self, agent_id: str) -> str:
        """Register a DID for an agent."""
        did = f"did:key:{agent_id}"
        sk = SecretKey(agent_id)
        pk = PublicKey(agent_id)
        self.agent_keys[agent_id] = (sk, pk)
        self.did_registry[did] = pk
        return did

    def resolve_did(self, did: str) -> Optional[Term]:
        """Resolve a DID to its public key via the registry."""
        return self.did_registry.get(did)

    def create_message(self, sender: str, receiver: str,
                       payload: Term, session_id: str,
                       step: int) -> ProtocolMessage:
        """
        DIDComm v2 message:
        msg = JWE(pk_j, sign(sk_i, (payload, nonce, did_i, did_j)))
        """
        sender_sk, _ = self.agent_keys.get(sender, (None, None))
        did_i = Name(f"did:key:{sender}")
        did_j = Name(f"did:key:{receiver}")
        nonce = Nonce(f"n_{session_id}_{step}")

        # Inner signed content
        inner = Pair(payload, Pair(nonce, Pair(did_i, did_j)))
        signed = Sign(inner, sender_sk)

        # Outer encryption (JWE envelope)
        receiver_pk = self.resolve_did(f"did:key:{receiver}")
        if receiver_pk is None:
            receiver_pk = PublicKey(receiver)
        encrypted = Enc(signed, receiver_pk)

        return ProtocolMessage(
            sender=sender, receiver=receiver,
            content=encrypted, session_id=session_id,
            step=step, is_authenticated=True
        )

    def verify_message(self, msg: ProtocolMessage) -> Tuple[bool, Optional[Term]]:
        """
        Receiving agent:
        1. Decrypts with own key
        2. Verifies sender signature using DID-resolved public key
        3. Checks nonce and DID fields
        """
        receiver_sk, _ = self.agent_keys.get(msg.receiver, (None, None))
        if receiver_sk is None:
            return False, None

        # Decrypt outer envelope
        signed = Dec(msg.content, receiver_sk)

        # Verify sender signature
        sender_pk = self.resolve_did(f"did:key:{msg.sender}")
        if sender_pk is None:
            return False, None

        verified_inner = Verify(signed, sender_pk)
        if verified_inner is None:
            return False, None

        # Extract payload (first element of the pair)
        if verified_inner.term_type == TermType.PAIR:
            payload = verified_inner.subterms[0]
            return True, payload

        return False, None

    def run_session(self, initiator: str, responder: str,
                    payload: Term) -> ProtocolSession:
        """Execute a DID-authenticated protocol session."""
        session_id = f"did_sess_{initiator}_{responder}"
        session = ProtocolSession(session_id, initiator, responder)

        # Step 1: Initiator sends DIDComm message
        msg1 = self.create_message(initiator, responder, payload,
                                   session_id, step=1)
        session.messages.append(msg1)

        # Step 2: Responder verifies and responds
        auth, recv_payload = self.verify_message(msg1)
        if auth:
            response = Name(f"ack_{session_id}")
            msg2 = self.create_message(responder, initiator, response,
                                       session_id, step=2)
            session.messages.append(msg2)
            auth2, _ = self.verify_message(msg2)
            session.completed = auth2
            session.authenticated = auth and auth2

        self.sessions[session_id] = session
        return session

    @property
    def protocol_type(self) -> ProtocolType:
        return ProtocolType.DECENTRALIZED_DID

    def get_security_properties(self) -> Dict[str, bool]:
        all_authenticated = all(s.authenticated for s in self.sessions.values())
        all_secret = all(s.secret_preserved for s in self.sessions.values())
        return {
            "authentication": all_authenticated,
            "secrecy": all_secret,
            "trust_assumption": "DID Registry",
            "single_point_of_failure": False,
        }
