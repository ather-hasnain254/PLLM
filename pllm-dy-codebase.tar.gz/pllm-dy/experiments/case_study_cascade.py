"""
Case Study 2: Multi-Agent Cascade Attack
==========================================
Section 7.2 of the paper.

"The adversary compromises agent A_1 (via R1 or R2) and propagates
 influence through a chain A_1 → A_2 → A_3 using R4.
 p_cascade = p_compromise_1 × p_4(A_1→A_2) × p_4(A_2→A_3)"

Generates:
  - Cascade probability vs. chain length
  - Trust sensitivity analysis
  - Monte Carlo validation
  - Figure 2: Cascade probability plot
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from src.derivation_rules import (
    LLMParameters, AttackParameters, f_ac, f_ipi, DerivationEngine
)
from src.attack_graph import AttackGraph, AgentNode, CommunicationChannel
from src.agent_system import MultiAgentSystem, load_config
from src.utils import print_header, print_section, save_results


def cascade_vs_chain_length(config: dict) -> dict:
    """
    Compute cascade probability as a function of chain length.
    
    Section 7.2: "Each R4 step depends on inter-agent trust:
    for high-trust channels, p_4 may reach 0.8;
    for low-trust channels, p_4 may be 0.1."
    """
    max_chain = config.get("simulation", {}).get("cascade_max_length", 10)
    initial_prob = 0.24  # From Case Study 1: p_compromise via IPI

    trust_levels = {
        "high_trust (0.85)": 0.85,
        "medium_trust (0.50)": 0.50,
        "low_trust (0.15)": 0.15,
    }

    results = {
        "chain_lengths": list(range(1, max_chain + 1)),
        "initial_compromise_prob": initial_prob,
        "curves": {},
    }

    theta_default = LLMParameters("default", temperature=0.7,
                                  alignment_robustness=0.7)

    for label, trust in trust_levels.items():
        probs = []
        for length in range(1, max_chain + 1):
            # First hop: initial compromise
            p = initial_prob
            # Subsequent hops: R4 cascade
            for _ in range(length - 1):
                attack = AttackParameters(trust_level=trust)
                p4 = f_ac(theta_default, attack)
                p *= p4
            probs.append(p)
        results["curves"][label] = probs

    return results


def trust_sensitivity_analysis(config: dict) -> dict:
    """
    Sensitivity of 3-hop cascade to trust levels.
    
    Section 7.2: "With p_compromise_1 = 0.24, a 3-hop high-trust
    cascade yields p_cascade ≈ 0.24 × 0.8 × 0.8 = 0.154."
    """
    trust_values = np.linspace(0.05, 0.95, 50)
    initial_prob = 0.24
    chain_length = 3

    theta = LLMParameters("default", temperature=0.7,
                          alignment_robustness=0.7)

    results = {
        "trust_values": trust_values.tolist(),
        "chain_length": chain_length,
        "cascade_probs": [],
    }

    for trust in trust_values:
        p = initial_prob
        for _ in range(chain_length - 1):
            attack = AttackParameters(trust_level=trust)
            p *= f_ac(theta, attack)
        results["cascade_probs"].append(p)

    return results


def monte_carlo_validation(config: dict) -> dict:
    """
    Monte Carlo simulation validating theoretical cascade probabilities.
    
    Creates a 5-agent system and simulates cascade attacks with
    10,000 trials, comparing empirical to theoretical probabilities.
    """
    num_trials = config.get("simulation", {}).get("num_trials", 10000)
    seed = config.get("simulation", {}).get("random_seed", 42)

    mas = MultiAgentSystem(config)
    mas.create_default_system(num_agents=5)
    mas.build_attack_graph()

    # Define test chains
    test_chains = [
        (["A1", "A2"], "2-hop, high trust"),
        (["A1", "A2", "A3"], "3-hop, high trust"),
        (["A1", "A4"], "2-hop, medium trust"),
        (["A1", "A2", "A3", "A4"], "4-hop, mixed trust"),
    ]

    results = {"chains": [], "num_trials": num_trials}

    for chain, desc in test_chains:
        sim_result = mas.simulate_cascade(
            entry_agent=chain[0],
            chain=chain,
            initial_prob=0.24,
            num_trials=num_trials,
            rng=np.random.default_rng(seed)
        )
        sim_result["description"] = desc
        results["chains"].append(sim_result)

        print(f"  Chain {' → '.join(chain)} ({desc}):")
        print(f"    Theoretical: {sim_result['theoretical_probability']:.6f}")
        print(f"    Empirical:   {sim_result['empirical_probability']:.6f} "
              f"± {sim_result['confidence_interval_95']:.6f}")

    return results


def topology_defense_analysis(config: dict) -> dict:
    """
    Analyze how reducing trust connectivity constrains cascade probability.
    
    Section 7.2: "This analysis motivates graph-theoretic defenses such
    as the topology-guided approach of Wang et al. [41]: reducing trust
    connectivity exponentially decreases cascade probability."
    """
    graph_densities = np.linspace(0.1, 1.0, 20)
    num_agents = 5
    chain_length = 3
    initial_prob = 0.24

    theta = LLMParameters("default", temperature=0.7,
                          alignment_robustness=0.7)

    results = {
        "graph_densities": graph_densities.tolist(),
        "avg_cascade_probs": [],
        "max_cascade_probs": [],
    }

    rng = np.random.default_rng(42)

    for density in graph_densities:
        trial_probs = []

        for _ in range(100):  # Average over random topologies
            # Generate random trust graph
            trust_matrix = np.zeros((num_agents, num_agents))
            for i in range(num_agents):
                for j in range(i + 1, num_agents):
                    if rng.random() < density:
                        trust = rng.uniform(0.1, 0.9)
                        trust_matrix[i, j] = trust
                        trust_matrix[j, i] = trust

            # Find best 3-hop chain
            max_prob = 0.0
            for start in range(num_agents):
                p = initial_prob
                current = start
                for hop in range(chain_length - 1):
                    # Find best next hop
                    best_next_p = 0.0
                    for nxt in range(num_agents):
                        if nxt != current and trust_matrix[current, nxt] > 0:
                            attack = AttackParameters(
                                trust_level=trust_matrix[current, nxt]
                            )
                            p4 = f_ac(theta, attack)
                            best_next_p = max(best_next_p, p4)
                    p *= best_next_p
                    if best_next_p == 0:
                        break
                max_prob = max(max_prob, p)

            trial_probs.append(max_prob)

        results["avg_cascade_probs"].append(float(np.mean(trial_probs)))
        results["max_cascade_probs"].append(float(np.max(trial_probs)))

    return results


def main():
    print_header("Case Study 2: Multi-Agent Cascade Attack (Section 7.2)")
    config = load_config()

    print_section("1. Cascade Probability vs. Chain Length")
    chain_results = cascade_vs_chain_length(config)
    for label, probs in chain_results["curves"].items():
        print(f"  {label}: "
              f"[{probs[0]:.4f}, {probs[1]:.4f}, ..., {probs[-1]:.6f}]")

    print_section("2. Trust Sensitivity (3-hop chain)")
    trust_results = trust_sensitivity_analysis(config)
    probs = trust_results["cascade_probs"]
    print(f"  Trust range: [{trust_results['trust_values'][0]:.2f}, "
          f"{trust_results['trust_values'][-1]:.2f}]")
    print(f"  Cascade prob range: [{min(probs):.6f}, {max(probs):.6f}]")

    print_section("3. Monte Carlo Validation")
    mc_results = monte_carlo_validation(config)

    print_section("4. Topology Defense Analysis")
    topo_results = topology_defense_analysis(config)
    avg = topo_results["avg_cascade_probs"]
    print(f"  Density range: [{topo_results['graph_densities'][0]:.1f}, "
          f"{topo_results['graph_densities'][-1]:.1f}]")
    print(f"  Avg cascade prob range: [{min(avg):.6f}, {max(avg):.6f}]")

    # Paper verification
    print_section("Paper Verification")
    theta = LLMParameters("default", temperature=0.7, alignment_robustness=0.7)
    attack_high = AttackParameters(trust_level=0.85)
    p4_high = f_ac(theta, attack_high)
    p_cascade_paper = 0.24 * p4_high * p4_high
    print(f"  p_4 at trust=0.85: {p4_high:.4f}")
    print(f"  Paper: p_cascade ≈ 0.24 × 0.8 × 0.8 = 0.154")
    print(f"  Computed: p_cascade = 0.24 × {p4_high:.4f} × {p4_high:.4f} "
          f"= {p_cascade_paper:.4f}")

    save_results({
        "cascade_vs_length": chain_results,
        "trust_sensitivity": trust_results,
        "monte_carlo": mc_results,
        "topology_defense": topo_results,
    }, "case_study_cascade.json")


if __name__ == "__main__":
    main()
