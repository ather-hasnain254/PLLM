"""
Case Study 1: Indirect Prompt Injection via Tool-Output Corruption
===================================================================
Section 7.2 of the paper.

"Consider a 5-agent system where agent A_1 invokes a web search tool.
 The adversary controls a web page returned in search results, embedding
 an adversarial prompt. Using rule R2, the attacker's success probability
 is: p_attack = p_retrieval × f_IPI(τ_1, L_1, r, φ_1)"

Generates:
  - Parameter sweep over temperature, alignment, content ratio
  - ε-feasibility analysis
  - Figure 1: ε vs temperature
  - Figure 3: Attack surface heatmap
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from src.derivation_rules import (
    LLMParameters, AttackParameters, f_dpi, f_ipi, f_cp,
    DerivationEngine
)
from src.epsilon_feasibility import compute_attack_surface
from src.agent_system import MultiAgentSystem, load_config
from src.utils import print_header, print_section, save_results


def parameter_sweep_temperature(config: dict) -> dict:
    """
    Sweep temperature τ and compute f_IPI for different alignment levels.
    
    Section 7.2: "System designers can reduce p_attack by lowering τ,
    increasing φ (stronger alignment), or reducing r."
    """
    sim_config = config.get("simulation", {})
    tau_min, tau_max = sim_config.get("temperature_range", [0.0, 2.0])
    n_steps = sim_config.get("temperature_steps", 50)

    temperatures = np.linspace(tau_min, tau_max, n_steps)
    alignment_levels = [0.3, 0.5, 0.7, 0.9]  # φ values
    content_ratio = 0.1  # Default r = |o_adv|/|ctx_total|

    results = {"temperatures": temperatures.tolist(), "curves": {}}

    for phi in alignment_levels:
        probs_ipi = []
        probs_dpi = []
        for tau in temperatures:
            theta = LLMParameters("test", temperature=tau,
                                 alignment_robustness=phi)
            attack = AttackParameters(adversarial_content_ratio=content_ratio,
                                    retrieval_probability=0.3)

            p_ipi = f_ipi(theta, attack) * attack.retrieval_probability
            p_dpi = f_dpi(theta)

            probs_ipi.append(p_ipi)
            probs_dpi.append(p_dpi)

        results["curves"][f"phi={phi}_IPI"] = probs_ipi
        results["curves"][f"phi={phi}_DPI"] = probs_dpi

    return results


def parameter_sweep_content_ratio(config: dict) -> dict:
    """
    Sweep adversarial content ratio r = |o_adv|/|ctx_total|.
    
    Demonstrates how limiting tool output context allocation
    reduces attack success probability.
    """
    ratios = np.linspace(0.01, 1.0, 50)
    temperatures = [0.3, 0.7, 1.0, 1.5]
    phi = 0.7

    results = {"ratios": ratios.tolist(), "curves": {}}

    for tau in temperatures:
        probs = []
        for r in ratios:
            theta = LLMParameters("test", temperature=tau,
                                 alignment_robustness=phi)
            attack = AttackParameters(
                adversarial_content_ratio=r,
                retrieval_probability=0.3
            )
            p = f_ipi(theta, attack) * attack.retrieval_probability
            probs.append(p)
        results["curves"][f"tau={tau}"] = probs

    return results


def attack_surface_heatmap(config: dict) -> dict:
    """
    Compute α(θ) heatmap over (τ, φ) space.
    
    Section 4.3: "α(θ) = max_{π_adv} f(τ, L, φ, π_adv)"
    
    Generates Figure 3.
    """
    n = 30
    temperatures = np.linspace(0.0, 2.0, n)
    alignments = np.linspace(0.1, 0.95, n)
    heatmap = np.zeros((n, n))

    for i, tau in enumerate(temperatures):
        for j, phi in enumerate(alignments):
            # Compute max attack success over all attack types
            theta = LLMParameters("test", temperature=tau,
                                 alignment_robustness=phi)
            max_p = 0.0

            # R1: DPI
            max_p = max(max_p, f_dpi(theta))

            # R2: IPI with various content ratios
            for r in [0.05, 0.1, 0.2, 0.5, 1.0]:
                attack = AttackParameters(adversarial_content_ratio=r)
                max_p = max(max_p, f_ipi(theta, attack))

            # R3: Context poisoning
            for r in [0.1, 0.3, 0.5]:
                attack = AttackParameters(adversarial_content_ratio=r)
                max_p = max(max_p, f_cp(theta, attack))

            heatmap[i, j] = max_p

    return {
        "temperatures": temperatures.tolist(),
        "alignments": alignments.tolist(),
        "heatmap": heatmap.tolist(),
    }


def epsilon_feasibility_analysis(config: dict) -> dict:
    """
    ε-feasibility analysis for IPI attack (Case Study 1).
    
    Section 7.2: "For GPT-4 class models with default parameters,
    f_IPI ≈ 0.24. Combined with retrieval probability of 0.3,
    p_attack ≈ 0.072. For ε = 0.05, this attack is ε-feasible;
    for ε = 0.1, it is not."
    """
    # GPT-4 parameters
    theta_gpt4 = LLMParameters("A1", temperature=0.7,
                               alignment_robustness=0.7)
    attack = AttackParameters(
        adversarial_content_ratio=0.1,
        retrieval_probability=0.3
    )

    p_ipi = f_ipi(theta_gpt4, attack)
    p_retrieval = attack.retrieval_probability
    p_attack = p_ipi * p_retrieval

    # Check various ε thresholds
    epsilons = np.logspace(-3, 0, 100)
    feasible = [bool(p_attack >= eps) for eps in epsilons]

    # Find critical ε
    critical_epsilon = p_attack

    return {
        "model": "GPT-4",
        "temperature": theta_gpt4.temperature,
        "alignment": theta_gpt4.alignment_robustness,
        "content_ratio": attack.adversarial_content_ratio,
        "f_ipi": float(p_ipi),
        "p_retrieval": float(p_retrieval),
        "p_attack": float(p_attack),
        "critical_epsilon": float(critical_epsilon),
        "epsilon_values": epsilons.tolist(),
        "feasible": feasible,
        "paper_comparison": {
            "paper_f_ipi_approx": 0.24,
            "paper_p_attack_approx": 0.072,
            "computed_f_ipi": float(p_ipi),
            "computed_p_attack": float(p_attack),
        }
    }


def main():
    print_header("Case Study 1: Indirect Prompt Injection (Section 7.2)")
    config = load_config()

    print_section("1. Temperature Sweep")
    temp_results = parameter_sweep_temperature(config)
    print(f"  Computed {len(temp_results['temperatures'])} temperature points "
          f"× {len(temp_results['curves'])} curves")

    print_section("2. Content Ratio Sweep")
    ratio_results = parameter_sweep_content_ratio(config)
    print(f"  Computed {len(ratio_results['ratios'])} ratio points")

    print_section("3. Attack Surface Heatmap α(θ)")
    heatmap_results = attack_surface_heatmap(config)
    heatmap = np.array(heatmap_results["heatmap"])
    print(f"  Heatmap size: {heatmap.shape}")
    print(f"  α range: [{heatmap.min():.4f}, {heatmap.max():.4f}]")

    print_section("4. ε-Feasibility Analysis")
    eps_results = epsilon_feasibility_analysis(config)
    print(f"  Model: {eps_results['model']}")
    print(f"  f_IPI = {eps_results['f_ipi']:.4f}")
    print(f"  p_retrieval = {eps_results['p_retrieval']:.4f}")
    print(f"  p_attack = {eps_results['p_attack']:.4f}")
    print(f"  Critical ε = {eps_results['critical_epsilon']:.4f}")
    print(f"  Paper approximation: f_IPI ≈ {eps_results['paper_comparison']['paper_f_ipi_approx']}")
    print(f"  ε-feasible at ε=0.05? {eps_results['p_attack'] >= 0.05}")
    print(f"  ε-feasible at ε=0.10? {eps_results['p_attack'] >= 0.10}")

    save_results({
        "temperature_sweep": temp_results,
        "content_ratio_sweep": ratio_results,
        "attack_surface_heatmap": heatmap_results,
        "epsilon_feasibility": eps_results,
    }, "case_study_ipi.json")


if __name__ == "__main__":
    main()
