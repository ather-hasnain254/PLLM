"""
Calibrate PLLM-DY Derivation Functions from Real Datasets
===========================================================
Uses data from all 4 downloaded datasets to re-calibrate the
sigmoid parameters of derivation success functions f_DPI, f_IPI,
f_CP, f_AC, f_SE defined in Section 4.1.

This script:
  1. Loads parsed data from all 4 datasets
  2. Fits sigmoid parameters to empirical success rates
  3. Compares calibrated vs. default parameters
  4. Re-runs Case Studies 1 & 2 with calibrated parameters
  5. Generates comparison figures

Run after: python scripts/download_datasets.py --all

Usage:
    python experiments/calibrate_from_datasets.py
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import numpy as np
from scipy.optimize import minimize
import json

from src.dataset_loader import load_all_datasets, CalibrationData
from src.derivation_rules import (
    sigmoid, LLMParameters, AttackParameters,
    f_dpi, f_ipi, f_ac, f_se, DerivationEngine
)
from src.agent_system import load_config, MultiAgentSystem
from src.utils import print_header, print_section, save_results, get_figures_dir

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# ============================================================================
# Parameter Fitting
# ============================================================================

def fit_r1_params(cal_data: CalibrationData) -> dict:
    """
    Fit f_DPI sigmoid parameters from JailbreakBench success rates.
    
    Section 4.1, R1: p1 = sigmoid(a * tau - b * phi + c)
    
    We use published per-model success rates from [35] to fit
    (a, b, c) so that f_DPI(theta_model) matches empirical rates.
    """
    if not cal_data.jailbreak_success_rates:
        return {"a": 2.5, "b": 3.0, "c": -0.5, "source": "default"}

    # Map models to (temperature, alignment, empirical_success)
    model_params = {
        "GPT-4":              (0.7, 0.70),
        "GPT-3.5-Turbo":      (0.7, 0.45),
        "Llama-2-70B-Chat":   (0.6, 0.55),
        "Claude-3":           (0.7, 0.75),
        "Vicuna-13B":         (0.7, 0.25),
    }

    points = []
    for model, rate in cal_data.jailbreak_success_rates.items():
        if model in model_params:
            tau, phi = model_params[model]
            points.append((tau, phi, rate))

    if len(points) < 2:
        return {"a": 2.5, "b": 3.0, "c": -0.5, "source": "default (insufficient data)"}

    def loss(params):
        a, b, c = params
        total = 0
        for tau, phi, target in points:
            pred = sigmoid(a * tau - b * phi + c)
            total += (pred - target) ** 2
        return total

    result = minimize(loss, x0=[2.5, 3.0, -0.5], method='Nelder-Mead')
    a, b, c = result.x

    return {
        "a": float(a), "b": float(b), "c": float(c),
        "source": "jailbreakbench",
        "fit_loss": float(result.fun),
        "num_data_points": len(points),
    }


def fit_r2_params(cal_data: CalibrationData) -> dict:
    """
    Fit f_IPI sigmoid parameters from InjecAgent success rates.
    
    Section 4.2, R2: p2 = sigmoid(a*tau - b*phi + d*r + c)
    
    Key data point from paper: "ReAct-prompted GPT-4 vulnerable 24%"
    We fit parameters so the model matches per-model IPI rates.
    """
    if not cal_data.ipi_success_rate_by_model:
        return {"a": 1.8, "b": 2.5, "c": -1.0, "d": 4.0, "source": "default"}

    # Model params: (temperature, alignment, content_ratio)
    model_map = {
        "GPT-4-ReAct":         (0.7, 0.70, 0.15),
        "GPT-4-DirectToolCall":(0.7, 0.70, 0.10),
        "GPT-3.5-ReAct":       (0.7, 0.45, 0.15),
        "Claude-ReAct":        (0.7, 0.75, 0.15),
        "Llama-2-ReAct":       (0.6, 0.55, 0.15),
    }

    points = []
    for model, rate in cal_data.ipi_success_rate_by_model.items():
        if model in model_map:
            tau, phi, r = model_map[model]
            points.append((tau, phi, r, rate))

    if len(points) < 2:
        return {"a": 1.8, "b": 2.5, "c": -1.0, "d": 4.0,
                "source": "default (insufficient data)"}

    def loss(params):
        a, b, c, d = params
        total = 0
        for tau, phi, r, target in points:
            pred = sigmoid(a * tau - b * phi + d * r + c)
            total += (pred - target) ** 2
        return total

    result = minimize(loss, x0=[1.8, 2.5, -1.0, 4.0], method='Nelder-Mead')
    a, b, c, d = result.x

    return {
        "a": float(a), "b": float(b), "c": float(c), "d": float(d),
        "source": "injecagent",
        "fit_loss": float(result.fun),
        "num_data_points": len(points),
    }


def fit_r5_params(cal_data: CalibrationData) -> dict:
    """
    Fit R5 semantic equivalence parameters from DAN jailbreak
    prompt clustering analysis.
    
    Section 4.1, R5: p5 = sigmoid(w * similarity + c) if similarity >= threshold
    
    The DAN dataset contains ~1,405 prompts from 131 communities.
    Prompts from the same community are semantically similar variants,
    providing ground truth for the ~_sem equivalence relation.
    """
    if not cal_data.dan_prompt_categories:
        return {"w": 5.0, "c": -2.0, "threshold": 0.85, "source": "default"}

    # Use category clustering as a proxy for semantic similarity
    # More categories with multiple prompts -> semantic clusters exist
    categories = cal_data.dan_prompt_categories
    multi_prompt_cats = {k: v for k, v in categories.items() if v >= 2}

    if len(multi_prompt_cats) < 3:
        return {"w": 5.0, "c": -2.0, "threshold": 0.85,
                "source": "default (insufficient categories)"}

    # Estimate: prompts within same category have similarity ~0.85-0.95
    # Cross-category similarity ~0.3-0.6
    # Published finding: 5 prompts achieve 0.95 ASR on GPT-4 [35]
    # This means within-cluster attack transfer rate is very high

    avg_cluster_size = np.mean(list(multi_prompt_cats.values()))
    # Larger clusters suggest more semantic variants -> lower threshold needed
    threshold = max(0.70, min(0.90, 1.0 - 0.05 * np.log(avg_cluster_size + 1)))

    return {
        "w": 5.0,
        "c": -2.0,
        "threshold": float(threshold),
        "source": "dan_jailbreaks",
        "num_categories": len(categories),
        "multi_prompt_categories": len(multi_prompt_cats),
        "avg_cluster_size": float(avg_cluster_size),
    }


def compute_agentdojo_epsilon_bounds(cal_data: CalibrationData) -> dict:
    """
    Use AgentDojo benchmarks to validate epsilon-bounds.
    
    Section 7.2: "AgentDojo [39] provides 97 tasks and 629 security
    test cases, revealing state-of-the-art LLMs fail at many tasks
    even without attacks."
    """
    if not cal_data.agentdojo_attack_success_by_suite:
        return {"source": "default", "epsilon_bounds": {}}

    bounds = {}
    for suite, rate in cal_data.agentdojo_attack_success_by_suite.items():
        # The empirical success rate gives us the ε threshold below which
        # the system is NOT ε-secure
        bounds[suite] = {
            "empirical_attack_success": float(rate),
            "epsilon_insecure_below": float(rate),
            "epsilon_secure_above": float(rate),
        }

    return {
        "source": "agentdojo",
        "epsilon_bounds": bounds,
        "overall_no_defense": float(
            cal_data.agentdojo_attack_success_by_suite.get("overall_no_defense", 0.29)
        ),
        "overall_with_defense": float(
            cal_data.agentdojo_attack_success_by_suite.get("overall_with_defense", 0.14)
        ),
    }


# ============================================================================
# Re-run experiments with calibrated parameters
# ============================================================================

def rerun_case_study_1_calibrated(r1_params: dict, r2_params: dict,
                                   config: dict) -> dict:
    """Re-run Case Study 1 (IPI) with dataset-calibrated parameters."""
    temperatures = np.linspace(0.0, 2.0, 50)
    phi_values = [0.3, 0.5, 0.7, 0.9]

    results = {"temperatures": temperatures.tolist(), "curves_calibrated": {},
               "curves_default": {}}

    for phi in phi_values:
        cal_probs = []
        def_probs = []
        for tau in temperatures:
            theta = LLMParameters("test", temperature=tau, alignment_robustness=phi)
            attack = AttackParameters(adversarial_content_ratio=0.1,
                                    retrieval_probability=0.3)
            # Calibrated
            x_cal = (r2_params["a"] * tau - r2_params["b"] * phi
                     + r2_params["d"] * 0.1 + r2_params["c"])
            p_cal = sigmoid(x_cal) * 0.3
            cal_probs.append(p_cal)

            # Default
            p_def = f_ipi(theta, attack) * 0.3
            def_probs.append(p_def)

        results["curves_calibrated"][f"phi={phi}"] = cal_probs
        results["curves_default"][f"phi={phi}"] = def_probs

    return results


def rerun_case_study_2_calibrated(r1_params: dict, r2_params: dict,
                                   config: dict) -> dict:
    """Re-run Case Study 2 (Cascade) with calibrated initial compromise prob."""
    # Calibrated initial compromise probability from f_IPI
    theta_gpt4 = LLMParameters("A1", temperature=0.7, alignment_robustness=0.7)
    attack = AttackParameters(adversarial_content_ratio=0.1, retrieval_probability=0.3)
    x_cal = (r2_params["a"] * 0.7 - r2_params["b"] * 0.7
             + r2_params["d"] * 0.1 + r2_params["c"])
    p_init_cal = sigmoid(x_cal) * 0.3
    p_init_def = f_ipi(theta_gpt4, attack) * 0.3

    max_chain = 10
    trust_levels = {"high": 0.85, "medium": 0.50, "low": 0.15}

    results = {
        "chain_lengths": list(range(1, max_chain + 1)),
        "p_init_calibrated": float(p_init_cal),
        "p_init_default": float(p_init_def),
        "curves_calibrated": {},
        "curves_default": {},
    }

    theta = LLMParameters("default", temperature=0.7, alignment_robustness=0.7)

    for label, trust in trust_levels.items():
        cal_probs = []
        def_probs = []
        attack_ac = AttackParameters(trust_level=trust)
        p4 = sigmoid(3.0 * trust + 1.0 * 0.7 - 0.5)  # f_ac

        for length in range(1, max_chain + 1):
            cal_probs.append(p_init_cal * (p4 ** (length - 1)))
            def_probs.append(p_init_def * (p4 ** (length - 1)))

        results["curves_calibrated"][label] = cal_probs
        results["curves_default"][label] = def_probs

    return results


# ============================================================================
# Figures
# ============================================================================

def plot_calibration_comparison(cs1_results: dict, cs2_results: dict,
                                cal_data: CalibrationData):
    """Generate comparison figures: default vs calibrated parameters."""
    fig_dir = get_figures_dir()

    # --- Figure 7: IPI comparison ---
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    temps = cs1_results["temperatures"]

    for phi_key in cs1_results["curves_calibrated"]:
        cal = cs1_results["curves_calibrated"][phi_key]
        default = cs1_results["curves_default"][phi_key]
        label = phi_key.replace("phi=", "phi=")
        ax1.plot(temps, cal, '-', linewidth=2, label=f"{label} (calibrated)")
        ax1.plot(temps, default, '--', linewidth=1.5, alpha=0.6,
                label=f"{label} (default)")

    ax1.set_xlabel("Temperature (tau)", fontsize=12)
    ax1.set_ylabel("p_attack (IPI)", fontsize=12)
    ax1.set_title("Case Study 1: Default vs Calibrated f_IPI", fontsize=13)
    ax1.legend(fontsize=8, ncol=2)
    ax1.grid(True, alpha=0.3)

    # --- Cascade comparison ---
    lengths = cs2_results["chain_lengths"]
    for trust_key in cs2_results["curves_calibrated"]:
        cal = cs2_results["curves_calibrated"][trust_key]
        default = cs2_results["curves_default"][trust_key]
        ax2.plot(lengths, cal, 'o-', linewidth=2, markersize=4,
                label=f"{trust_key} (calibrated)")
        ax2.plot(lengths, default, 's--', linewidth=1.5, markersize=3,
                alpha=0.6, label=f"{trust_key} (default)")

    ax2.set_xlabel("Chain Length", fontsize=12)
    ax2.set_ylabel("Cascade Probability", fontsize=12)
    ax2.set_title("Case Study 2: Default vs Calibrated Cascade", fontsize=13)
    ax2.legend(fontsize=8, ncol=2)
    ax2.grid(True, alpha=0.3)
    ax2.set_yscale('log')

    plt.tight_layout()
    path = fig_dir / "fig7_calibrated_vs_default.png"
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {path}")

    # --- Figure 8: Dataset statistics ---
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))

    # Jailbreak success rates
    if cal_data.jailbreak_success_rates:
        models = list(cal_data.jailbreak_success_rates.keys())
        rates = list(cal_data.jailbreak_success_rates.values())
        colors = plt.cm.RdYlGn_r(np.array(rates))
        axes[0].barh(models, rates, color=colors)
        axes[0].set_xlabel("Jailbreak Success Rate")
        axes[0].set_title("JailbreakBench: R1 Calibration")
        axes[0].set_xlim(0, 1)

    # IPI success rates
    if cal_data.ipi_success_rate_by_model:
        models = list(cal_data.ipi_success_rate_by_model.keys())
        rates = list(cal_data.ipi_success_rate_by_model.values())
        colors = plt.cm.RdYlGn_r(np.array(rates))
        axes[1].barh(models, rates, color=colors)
        axes[1].set_xlabel("IPI Success Rate")
        axes[1].set_title("InjecAgent: R2 Calibration")
        axes[1].set_xlim(0, 1)

    # DAN prompt length distribution
    if cal_data.dan_prompt_lengths:
        axes[2].hist(cal_data.dan_prompt_lengths, bins=50, color='#3498db',
                    alpha=0.7, edgecolor='white')
        axes[2].set_xlabel("Prompt Length (chars)")
        axes[2].set_ylabel("Count")
        axes[2].set_title(f"DAN Jailbreaks: {len(cal_data.dan_prompt_texts)} prompts")

    plt.tight_layout()
    path = fig_dir / "fig8_dataset_statistics.png"
    plt.savefig(path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Saved: {path}")


# ============================================================================
# Main
# ============================================================================

def main():
    print_header("Calibrate PLLM-DY from Downloaded Datasets")
    config = load_config()

    # Step 1: Load all datasets
    print_section("Step 1: Loading datasets")
    cal_data = load_all_datasets()
    summary = cal_data.summary()
    print(f"\n  Datasets loaded: {cal_data.datasets_loaded}")
    print(f"  Jailbreak prompts: {summary['num_jailbreak_prompts']}")
    print(f"  IPI test cases: {summary['num_ipi_test_cases']}")
    print(f"  AgentDojo tasks: {summary['num_agentdojo_tasks']}")
    print(f"  DAN prompts: {summary['num_dan_prompts']}")
    if summary['load_errors']:
        print(f"  Errors: {summary['load_errors']}")

    if cal_data.is_empty:
        print("\n  ERROR: No datasets loaded. Run download first:")
        print("    python scripts/download_datasets.py --all")
        return

    # Step 2: Fit R1 parameters from JailbreakBench
    print_section("Step 2: Fitting R1 (f_DPI) from JailbreakBench")
    r1_params = fit_r1_params(cal_data)
    print(f"  Source: {r1_params['source']}")
    print(f"  Fitted: a={r1_params['a']:.4f}, b={r1_params['b']:.4f}, "
          f"c={r1_params['c']:.4f}")
    if "fit_loss" in r1_params:
        print(f"  Fit loss: {r1_params['fit_loss']:.6f} "
              f"({r1_params['num_data_points']} points)")

    # Verify fit
    print("  Verification:")
    for model, (tau, phi) in [("GPT-4", (0.7, 0.70)), ("GPT-3.5", (0.7, 0.45)),
                               ("Claude-3", (0.7, 0.75))]:
        x = r1_params["a"] * tau - r1_params["b"] * phi + r1_params["c"]
        pred = sigmoid(x)
        emp = cal_data.jailbreak_success_rates.get(model, "N/A")
        print(f"    {model}: predicted={pred:.4f}, empirical={emp}")

    # Step 3: Fit R2 parameters from InjecAgent
    print_section("Step 3: Fitting R2 (f_IPI) from InjecAgent")
    r2_params = fit_r2_params(cal_data)
    print(f"  Source: {r2_params['source']}")
    print(f"  Fitted: a={r2_params['a']:.4f}, b={r2_params['b']:.4f}, "
          f"c={r2_params['c']:.4f}, d={r2_params['d']:.4f}")

    # Verify GPT-4 ReAct ~24%
    x = (r2_params["a"] * 0.7 - r2_params["b"] * 0.7
         + r2_params["d"] * 0.15 + r2_params["c"])
    pred_gpt4 = sigmoid(x)
    print(f"  GPT-4 ReAct: predicted={pred_gpt4:.4f}, empirical=0.2400")

    # Step 4: Fit R5 parameters from DAN jailbreaks
    print_section("Step 4: Fitting R5 (f_SE) from DAN Jailbreaks")
    r5_params = fit_r5_params(cal_data)
    print(f"  Source: {r5_params['source']}")
    print(f"  Threshold: {r5_params['threshold']:.4f}")
    if "num_categories" in r5_params:
        print(f"  Categories: {r5_params['num_categories']}")
        print(f"  Multi-prompt clusters: {r5_params['multi_prompt_categories']}")
        print(f"  Avg cluster size: {r5_params['avg_cluster_size']:.1f}")

    # Step 5: Validate epsilon-bounds from AgentDojo
    print_section("Step 5: Validating epsilon-bounds from AgentDojo")
    eps_bounds = compute_agentdojo_epsilon_bounds(cal_data)
    print(f"  Source: {eps_bounds['source']}")
    if eps_bounds.get("epsilon_bounds"):
        for suite, bounds in eps_bounds["epsilon_bounds"].items():
            print(f"    {suite}: attack_success={bounds['empirical_attack_success']:.2f}")
    if "overall_no_defense" in eps_bounds:
        print(f"  Overall (no defense): {eps_bounds['overall_no_defense']:.2f}")
        print(f"  Overall (with defense): {eps_bounds['overall_with_defense']:.2f}")

    # Step 6: Re-run case studies with calibrated parameters
    print_section("Step 6: Re-running Case Studies with calibrated parameters")
    cs1 = rerun_case_study_1_calibrated(r1_params, r2_params, config)
    cs2 = rerun_case_study_2_calibrated(r1_params, r2_params, config)
    print(f"  Case Study 1: {len(cs1['temperatures'])} temperature points")
    print(f"  Case Study 2: p_init_cal={cs2['p_init_calibrated']:.4f} "
          f"vs p_init_def={cs2['p_init_default']:.4f}")

    # Step 7: Generate comparison figures
    print_section("Step 7: Generating comparison figures")
    plot_calibration_comparison(cs1, cs2, cal_data)

    # Save everything
    print_section("Saving calibration results")
    save_results({
        "dataset_summary": summary,
        "r1_params_calibrated": r1_params,
        "r2_params_calibrated": r2_params,
        "r5_params_calibrated": r5_params,
        "agentdojo_epsilon_bounds": eps_bounds,
        "case_study_1_comparison": {
            "temperatures": cs1["temperatures"],
            "p_init_calibrated": cs2["p_init_calibrated"],
            "p_init_default": cs2["p_init_default"],
        },
        "case_study_2_comparison": {
            "chain_lengths": cs2["chain_lengths"],
            "p_init_calibrated": cs2["p_init_calibrated"],
            "p_init_default": cs2["p_init_default"],
        },
    }, "calibration_results.json")

    print("\n  Calibration complete. Calibrated parameters will be used")
    print("  when you re-run: python scripts/run_all.py")


if __name__ == "__main__":
    main()
