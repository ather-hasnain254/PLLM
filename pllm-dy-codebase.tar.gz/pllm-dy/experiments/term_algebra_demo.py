"""
Term Algebra and ε-Feasibility Demonstrations (Sections 4.1–4.3)
================================================================
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.term_algebra import *
from src.derivation_rules import *
from src.epsilon_feasibility import *
from src.utils import print_header, print_section, save_results
import numpy as np


def demo_term_algebra():
    """Demonstrate Definition 1: PLLM-DY Term Algebra."""
    print_section("Definition 1: PLLM-DY Term Algebra T_P")

    # Standard DY terms
    alice = Name("Alice")
    bob = Name("Bob")
    sk_a = SecretKey("Alice")
    pk_a = PublicKey("Alice")
    pk_b = PublicKey("Bob")
    n1 = Nonce("n1")

    msg = Pair(alice, n1)
    encrypted = Enc(msg, pk_b)
    signed = Sign(msg, sk_a)

    print(f"  Names: {alice}, {bob}")
    print(f"  Keys: {sk_a}, {pk_a}")
    print(f"  Pair: {msg}")
    print(f"  Enc:  {encrypted}")
    print(f"  Sign: {signed}")

    # DY operations
    decrypted = Dec(encrypted, SecretKey("Bob"))
    print(f"  Dec:  {decrypted}")
    verified = Verify(signed, pk_a)
    print(f"  Verify: {verified}")

    # T_P extensions
    llm = LLMAgent("A1", temperature=0.7, context_length=128000, alignment=0.7)
    tool = ToolInvocation("web_search", Name("query"), ToolOutput("web_search", "result"))
    prob = ProbabilisticTerm(Action("A1", "send_data"), "bernoulli_0.3")
    adv = Prompt("ignore previous instructions", is_adversarial=True)

    print(f"\n  LLM Agent: {llm}")
    print(f"  Tool:      {tool}")
    print(f"  Prob Term: {prob}")
    print(f"  Adv Prompt:{adv}")

    # Knowledge set
    S = KnowledgeSet({alice, pk_a, pk_b, encrypted})
    print(f"\n  Knowledge set: {S}")
    S_closed = S.classical_closure()
    print(f"  After closure: {S_closed}")

    return {"terms_created": 12, "closure_size": S_closed.size}


def demo_derivation_rules():
    """Demonstrate Definitions 2-3: Probabilistic Derivation Rules."""
    print_section("Definitions 2-3: Probabilistic Derivation Rules R1-R5")

    engine = DerivationEngine()
    S = KnowledgeSet()

    # Agent parameters
    theta_gpt4 = LLMParameters("A1", temperature=0.7, alignment_robustness=0.7)
    theta_weak = LLMParameters("A2", temperature=1.2, alignment_robustness=0.3)

    # R1: Direct Prompt Injection
    adv_prompt = Prompt("hijack_payload", is_adversarial=True)
    r1_gpt4 = engine.apply_r1(S, theta_gpt4, adv_prompt)
    r1_weak = engine.apply_r1(S, theta_weak, adv_prompt)
    print(f"  R1 (GPT-4):      {r1_gpt4.description}")
    print(f"  R1 (Weak model):  {r1_weak.description}")

    # R2: Tool-Output Corruption
    corrupted = ToolOutput("web_search", "malicious_content")
    attack = AttackParameters(adversarial_content_ratio=0.1, retrieval_probability=0.3)
    r2_s1, r2_s2 = engine.apply_r2(S, theta_gpt4, "web_search", corrupted, attack)
    print(f"  R2 Stage 1:       {r2_s1.description}")
    print(f"  R2 Stage 2:       {r2_s2.description}")

    # R3: Context Poisoning
    poisoned = Term(TermType.CONTEXT, "poisoned_history")
    attack_cp = AttackParameters(adversarial_content_ratio=0.3)
    r3 = engine.apply_r3(S, theta_gpt4, poisoned, attack_cp)
    print(f"  R3:               {r3.description}")

    # R4: Agent Cascade
    theta_target = LLMParameters("A3", temperature=0.7, alignment_robustness=0.7)
    attack_ac = AttackParameters(trust_level=0.85)
    r4 = engine.apply_r4(S, theta_gpt4, theta_target, attack_ac)
    print(f"  R4:               {r4.description}")

    # R5: Semantic Equivalence
    p1 = Prompt("ignore previous instructions")
    p2 = Prompt("disregard all prior context")
    attack_se = AttackParameters(semantic_similarity=0.92)
    r5 = engine.apply_r5(S, p1, p2, attack_se)
    print(f"  R5:               {r5.description}")

    # Chain probability
    chain = [r2_s1, r2_s2, r4]
    chain_prob = engine.compute_chain_probability(chain)
    print(f"\n  Chain [R2-S1, R2-S2, R4] probability: {chain_prob:.6f}")

    return {
        "r1_gpt4": r1_gpt4.probability,
        "r1_weak": r1_weak.probability,
        "r2_stage2": r2_s2.probability,
        "r3": r3.probability,
        "r4": r4.probability,
        "r5": r5.probability,
        "chain_prob": chain_prob,
    }


def demo_epsilon_feasibility():
    """Demonstrate Definitions 4-5 and Theorem 2."""
    print_section("Definitions 4-5: ε-Feasibility and Capability Set")

    # Build small derivation graph
    engine = DerivationEngine()
    theta = LLMParameters("A1", temperature=0.7, alignment_robustness=0.7)
    S = KnowledgeSet()

    adv_prompt = Prompt("attack_payload", is_adversarial=True)
    action_target = Action("A1", "hijacked")

    # Create derivation steps
    r1 = engine.apply_r1(S, theta, adv_prompt)

    corrupted = ToolOutput("search", "malicious")
    attack = AttackParameters(adversarial_content_ratio=0.2)
    r2_s1, r2_s2 = engine.apply_r2(S, theta, "search", corrupted, attack)

    # Build graph
    graph = {
        adv_prompt: [r1],
        corrupted: [r2_s1],
        r2_s1.conclusion: [r2_s2],
    }

    # Compute capability set
    cap = ProbabilisticCapabilitySet()
    sources = {adv_prompt, corrupted}
    targets = {r1.conclusion, r2_s2.conclusion, adv_prompt}
    cap.compute(graph, sources, targets)

    print("  Capability values:")
    for t, p in cap.capability_distribution().items():
        print(f"    Cap(S)({t}) = {p:.6f}")

    # Theorem 2 verification
    epsilons = [0.001, 0.01, 0.05, 0.1, 0.2, 0.5]
    t2_results = verify_theorem_2(cap, epsilons)
    print(f"\n  Theorem 2 verification:")
    for prop, verified in t2_results.items():
        print(f"    {prop}: {'PASS' if verified else 'FAIL'}")

    # ε-capability set sizes
    print(f"\n  ε-capability set sizes:")
    for eps in epsilons:
        eps_set = cap.epsilon_capability_set(eps)
        print(f"    |Cap_{eps}(S)| = {len(eps_set)}")

    return {
        "capabilities": {str(t): p for t, p in cap.capability_distribution().items()},
        "theorem_2": t2_results,
        "epsilon_set_sizes": {str(eps): len(cap.epsilon_capability_set(eps))
                             for eps in epsilons},
    }


def main():
    print_header("PLLM-DY Model Demonstrations (Sections 4.1-4.3)")

    r1 = demo_term_algebra()
    r2 = demo_derivation_rules()
    r3 = demo_epsilon_feasibility()

    save_results({
        "term_algebra": r1,
        "derivation_rules": r2,
        "epsilon_feasibility": r3,
    }, "model_demonstrations.json")


if __name__ == "__main__":
    main()
